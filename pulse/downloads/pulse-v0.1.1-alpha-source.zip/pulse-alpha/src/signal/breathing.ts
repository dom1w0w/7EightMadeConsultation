import { acPeriod, mean } from './dsp';

export interface Beat {
  /** timestamp (ms) */
  t: number;
  /** peak-to-trough amplitude of the filtered pulse */
  amp: number;
  /** captured during detected motion — excluded from estimates */
  motion?: boolean;
}

export interface BreathingEstimate {
  rate: number;
  confidence: number;
}

const RS = 4; // Hz for the beat-series resample

function resampleBeats(b: Beat[], get: (k: number) => number): number[] {
  const out: number[] = [];
  let j = 1;
  const end = b[b.length - 1].t;
  for (let t = b[1].t; t <= end; t += 1000 / RS) {
    while (j < b.length - 1 && b[j + 1].t < t) j++;
    const k2 = Math.min(j + 1, b.length - 1);
    const f = b[k2].t > b[j].t ? Math.max(0, Math.min(1, (t - b[j].t) / (b[k2].t - b[j].t))) : 0;
    out.push(get(j) + (get(k2) - get(j)) * f);
  }
  const w = 16; // ±4 s detrend
  return out.map((v, i) => v - mean(out, Math.max(0, i - w), Math.min(out.length, i + w)));
}

/**
 * Breathing-rate estimate from respiratory modulation of the pulse:
 * beat-to-beat interval (respiratory sinus arrhythmia) and beat amplitude.
 * Returns null when the read is too short or the modulation is not clear.
 */
export function estimateBreathing(beats: Beat[], since = 0): BreathingEstimate | null {
  const b = beats.filter((x) => x.t >= since && !x.motion);
  if (b.length < 14) return null;
  if ((b[b.length - 1].t - b[0].t) / 1000 < 18) return null;
  const ibi = resampleBeats(b, (k) => b[k].t - b[Math.max(0, k - 1)].t);
  const amp = resampleBeats(b, (k) => b[k].amp);
  let best: { lag: number; score: number } | null = null;
  for (const s of [ibi, amp]) {
    const r = acPeriod(s, 8, Math.min(48, Math.floor(s.length / 2) - 1), 0.6); // 5–30 br/min
    if (r && (!best || r.score > best.score)) best = r;
  }
  if (!best || best.score < 0.22) return null;
  const rate = (60 * RS) / best.lag;
  if (rate < 5 || rate > 30) return null;
  return { rate: Math.round(rate), confidence: best.score };
}
