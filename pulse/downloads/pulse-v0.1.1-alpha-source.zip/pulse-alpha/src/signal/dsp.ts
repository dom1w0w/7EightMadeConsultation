/** Core DSP helpers for camera photoplethysmography (PPG). Pure functions — no DOM. */

/** Uniform resample rate used by the whole pipeline (Hz). */
export const FS = 30;

export function mean(a: ArrayLike<number>, s = 0, e = a.length): number {
  if (e <= s) return 0;
  let t = 0;
  for (let i = s; i < e; i++) t += a[i];
  return t / (e - s);
}

export function std(a: ArrayLike<number>, s = 0, e = a.length): number {
  if (e - s < 2) return 0;
  const m = mean(a, s, e);
  let t = 0;
  for (let i = s; i < e; i++) t += (a[i] - m) * (a[i] - m);
  return Math.sqrt(t / (e - s - 1));
}

export function median(a: readonly number[]): number {
  if (!a.length) return 0;
  const c = [...a].sort((x, y) => x - y);
  const m = c.length >> 1;
  return c.length % 2 ? c[m] : (c[m - 1] + c[m]) / 2;
}

/** Second-order Butterworth section (RBJ cookbook, Q = 1/sqrt2). */
export class Biquad {
  private b0: number;
  private b1: number;
  private b2: number;
  private a1: number;
  private a2: number;
  private x1 = 0;
  private x2 = 0;
  private y1 = 0;
  private y2 = 0;

  constructor(type: 'lp' | 'hp', freq: number, fs: number) {
    const w0 = (2 * Math.PI * freq) / fs;
    const c = Math.cos(w0);
    const al = Math.sin(w0) / (2 * Math.SQRT1_2);
    const a0 = 1 + al;
    if (type === 'lp') {
      this.b0 = (1 - c) / 2 / a0;
      this.b1 = (1 - c) / a0;
      this.b2 = (1 - c) / 2 / a0;
    } else {
      this.b0 = (1 + c) / 2 / a0;
      this.b1 = -(1 + c) / a0;
      this.b2 = (1 + c) / 2 / a0;
    }
    this.a1 = (-2 * c) / a0;
    this.a2 = (1 - al) / a0;
  }

  reset(): void {
    this.x1 = this.x2 = this.y1 = this.y2 = 0;
  }

  step(x: number): number {
    const y = this.b0 * x + this.b1 * this.x1 + this.b2 * this.x2 - this.a1 * this.y1 - this.a2 * this.y2;
    this.x2 = this.x1;
    this.x1 = x;
    this.y2 = this.y1;
    this.y1 = y;
    return y;
  }
}

/** 4th-order band-pass (two HP + two LP Butterworth sections). Default 0.6–3.5 Hz = 36–210 bpm. */
export class BandPass {
  private s: Biquad[];
  constructor(lo = 0.6, hi = 3.5, fs = FS) {
    this.s = [new Biquad('hp', lo, fs), new Biquad('hp', lo, fs), new Biquad('lp', hi, fs), new Biquad('lp', hi, fs)];
  }
  reset(): void {
    this.s.forEach((b) => b.reset());
  }
  step(x: number): number {
    let y = x;
    for (const b of this.s) y = b.step(y);
    return y;
  }
}

export interface Period {
  /** period in samples (sub-sample precision via parabolic interpolation) */
  lag: number;
  /** normalized autocorrelation at that lag, 0..1 — our periodicity / quality score */
  score: number;
}

/**
 * Autocorrelation period finder with a harmonic guard: picks the shortest-lag
 * local peak that is nearly as strong as the strongest one, so a double-period
 * (half-rate) answer is not reported when the true beat is present.
 * `guard` = how strong (vs. the best peak) a shorter-lag peak must be to win.
 */
export function acPeriod(x: readonly number[], minLag: number, maxLag: number, guard = 0.86): Period | null {
  const n = x.length;
  if (n < maxLag * 2 || minLag < 1) return null;
  const m = mean(x);
  const d = x.map((v) => v - m);
  let r0 = 0;
  for (let i = 0; i < n; i++) r0 += d[i] * d[i];
  if (r0 <= 1e-9) return null;
  const r: number[] = [];
  for (let k = 0; k <= maxLag + 1; k++) {
    let s = 0;
    for (let i = 0; i + k < n; i++) s += d[i] * d[i + k];
    r[k] = (s / r0) * (n / (n - k));
  }
  let best = -Infinity;
  let bestK = -1;
  for (let k = minLag; k <= maxLag; k++) {
    if (r[k] > best && r[k] >= r[k - 1] && r[k] >= r[k + 1]) {
      best = r[k];
      bestK = k;
    }
  }
  if (bestK < 0 || best <= 0) return null;
  for (let k = minLag; k < bestK; k++) {
    if (r[k] >= r[k - 1] && r[k] >= r[k + 1] && r[k] > guard * best) {
      bestK = k;
      best = r[k];
      break;
    }
  }
  const a = r[bestK - 1];
  const b = r[bestK];
  const c = r[bestK + 1];
  const den = a - 2 * b + c;
  let off = den !== 0 ? (0.5 * (a - c)) / den : 0;
  if (Math.abs(off) > 1) off = 0;
  return { lag: bestK + off, score: Math.max(0, Math.min(1, best)) };
}

/** Clamp helper. */
export const clamp = (v: number, lo: number, hi: number): number => Math.max(lo, Math.min(hi, v));
