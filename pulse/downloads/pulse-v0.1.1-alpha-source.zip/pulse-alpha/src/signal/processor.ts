import { acPeriod, BandPass, FS, std } from './dsp';
import { fingerState, type FingerState, type FrameStats } from './finger';
import { estimateBreathing, type Beat, type BreathingEstimate } from './breathing';

const WIN = FS * 8; // 8 s analysis window
const KEEP = FS * 75; // history kept
const MIN_BPM = 38;
const MAX_BPM = 190;

export type SignalStatus = 'starting' | 'locking' | 'ok' | 'weak' | 'motion' | Exclude<FingerState, 'ok' | 'dim'>;

export interface LiveState {
  now: number;
  status: SignalStatus;
  finger: FingerState;
  /** live heart-rate estimate (0 = not locked) */
  bpm: number;
  /** signal quality 0..1 (periodicity of the band-passed pulse) */
  quality: number;
  channel: 'red' | 'green';
}

class Channel {
  private bp = new BandPass(0.6, 3.5, FS);
  // gentler display filter: keeps the true pulse shape (sharp upstroke, slower fall)
  private disp = new BandPass(0.3, 6, FS);
  private dc = 0;
  y: number[] = [];
  d: number[] = [];
  push(raw: number): number {
    this.dc = this.dc ? this.dc + (raw - this.dc) * 0.02 : raw;
    // relative change in permille, inverted: more blood in the fingertip = less light through it
    const x = (-(raw - this.dc) / Math.max(1, this.dc)) * 1000;
    const y = this.bp.step(x);
    this.y.push(y);
    this.d.push(this.disp.step(x));
    if (this.y.length > KEEP) {
      this.y.shift();
      this.d.shift();
    }
    return y;
  }
}

/**
 * Streaming camera-PPG processor. Feed it frame summaries (any frame rate, jittery
 * timing is fine) and read live state, waveform, beats and a breathing estimate.
 *
 * Pipeline: uniform 30 Hz resample -> per-channel DC-normalised 0.6–3.5 Hz band-pass
 * -> autocorrelation HR on 8 s window (best of red/green) -> peak picking for beats
 * -> motion gate on brightness jumps -> breathing from beat modulation.
 */
export class PulseProcessor {
  private red = new Channel();
  private green = new Channel();
  private uniT: number[] = [];
  private prev: { t: number; r: number; g: number } | null = null;
  private nextT = 0;
  private n = 0;
  private lastBright = 0;
  private dAvg = 0;
  private motionUntil = 0;
  private fingerSince = 0;
  private hr = 0;
  private hrQ = 0;
  private lastFrame: FrameStats | null = null;
  channel: 'red' | 'green' = 'red';
  beats: Beat[] = [];
  onBeat: ((t: number) => void) | null = null;
  status: SignalStatus = 'starting';

  ingest(t: number, s: FrameStats): void {
    this.lastFrame = s;
    const fs = fingerState(s);
    if (fs === 'ok' || fs === 'dim') {
      if (!this.fingerSince) this.fingerSince = t;
    } else {
      this.fingerSince = 0;
    }
    if (!this.prev) {
      this.prev = { t, r: s.r, g: s.g };
      this.nextT = t;
      this.lastBright = s.r;
      return;
    }
    const p = this.prev;
    const step = 1000 / FS;
    if (t - this.nextT > 1500) this.nextT = t; // stall (tab hidden) — skip ahead
    while (this.nextT <= t) {
      const f = t > p.t ? Math.max(0, (this.nextT - p.t) / (t - p.t)) : 1;
      this.pushUniform(this.nextT, p.r + (s.r - p.r) * f, p.g + (s.g - p.g) * f);
      this.nextT += step;
    }
    this.prev = { t, r: s.r, g: s.g };
  }

  private pushUniform(t: number, r: number, g: number): void {
    this.n++;
    // Motion gate: sudden brightness change far beyond the normal pulsatile slope
    // (>1.4 % per sample AND >3x the steepest recent pulse slope)
    const jump = (Math.abs(r - this.lastBright) / Math.max(1, r)) * 1000;
    this.lastBright = r;
    // dAvg tracks a slowly-decaying envelope of the steepest normal (pulse) slope
    const moving = jump > 14 && jump > 3 * this.dAvg;
    if (moving) this.motionUntil = t + 1200;
    else this.dAvg = Math.max(jump, this.dAvg * 0.99);
    this.red.push(r);
    this.green.push(g);
    this.uniT.push(t);
    if (this.uniT.length > KEEP) this.uniT.shift();
    if (this.n % 8 === 0) this.estimate(t);
    this.detectPeak();
  }

  private get sig(): number[] {
    return this.channel === 'green' ? this.green.y : this.red.y;
  }

  private estimate(t: number): void {
    if (this.red.y.length < WIN) {
      this.hrQ = 0;
      return;
    }
    const minLag = Math.round((FS * 60) / MAX_BPM);
    const maxLag = Math.round((FS * 60) / MIN_BPM);
    const a = acPeriod(this.red.y.slice(-WIN), minLag, maxLag);
    const b = acPeriod(this.green.y.slice(-WIN), minLag, maxLag);
    let pick = a;
    this.channel = 'red';
    if (b && (!a || b.score > a.score + 0.05)) {
      pick = b;
      this.channel = 'green';
    }
    if (!pick) {
      this.hrQ *= 0.5;
      return;
    }
    const hr = (60 * FS) / pick.lag;
    let q = pick.score;
    if (t < this.motionUntil) q *= 0.4;
    this.hr = this.hr && Math.abs(hr - this.hr) < 25 ? this.hr * 0.6 + hr * 0.4 : hr;
    this.hrQ = this.hrQ ? this.hrQ * 0.5 + q * 0.5 : q;
  }

  private detectPeak(): void {
    const y = this.sig;
    const n = y.length;
    const h = 7; // ±0.23 s neighbourhood
    if (n < FS * 3) return;
    const i = n - 1 - h;
    const c = y[i];
    for (let k = i - h; k <= i + h; k++) if (y[k] > c) return;
    if (c < 0.45 * std(y, Math.max(0, n - FS * 4), n)) return;
    // sub-sample peak time (parabolic interpolation) — 33 ms frames are too coarse for beat intervals
    const a = y[i - 1];
    const b = y[i + 1];
    const den = a - 2 * c + b;
    const off = den !== 0 ? Math.max(-0.5, Math.min(0.5, (0.5 * (a - b)) / den)) : 0;
    const tt = this.uniT[this.uniT.length - 1 - h] + (off * 1000) / FS;
    const last = this.beats.length ? this.beats[this.beats.length - 1].t : 0;
    if (tt - last < 320) return;
    if (this.hr > 0 && last && tt - last < (0.55 * 60000) / this.hr) return;
    let trough = Infinity;
    for (let k = Math.max(0, i - FS); k < i; k++) if (y[k] < trough) trough = y[k];
    this.beats.push({ t: tt, amp: c - trough, motion: tt < this.motionUntil });
    while (this.beats.length && tt - this.beats[0].t > 75000) this.beats.shift();
    if (this.status === 'ok' && this.onBeat) this.onBeat(tt);
  }

  /** Compute the live state at time `now` (call once per animation frame). */
  state(now: number): LiveState {
    const finger = fingerState(this.lastFrame);
    const settled = this.fingerSince > 0 && now - this.fingerSince > 1500;
    let status: SignalStatus;
    if (finger !== 'ok' && finger !== 'dim') status = finger;
    else if (now < this.motionUntil) status = 'motion';
    else if (!settled || this.red.y.length < WIN) status = 'locking';
    else status = this.hrQ >= 0.35 ? 'ok' : 'weak';
    this.status = status;
    const showQ = status === 'ok' || status === 'weak';
    return {
      now,
      status,
      finger,
      bpm: this.hr ? Math.round(this.hr) : 0,
      quality: showQ ? this.hrQ : 0,
      channel: this.channel,
    };
  }

  /** Recent waveform for drawing (display-filtered, shape-preserving). */
  wave(ms: number): { pts: { t: number; v: number }[]; end: number; beats: Beat[] } {
    const y = this.channel === 'green' ? this.green.d : this.red.d;
    const T = this.uniT;
    const n = Math.min(y.length, T.length);
    const end = T[T.length - 1] ?? 0;
    const pts: { t: number; v: number }[] = [];
    for (let i = Math.max(0, n - Math.ceil((ms / 1000) * FS) - 2); i < n; i++) {
      pts.push({ t: T[T.length - n + i], v: y[y.length - n + i] });
    }
    return { pts, end, beats: this.beats.filter((b) => end - b.t <= ms) };
  }

  breathing(since: number): BreathingEstimate | null {
    return estimateBreathing(this.beats, since);
  }
}
