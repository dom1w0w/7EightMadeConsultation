import type { FrameStats } from './finger';

export interface SynthOptions {
  /** starting heart rate */
  bpm?: number;
  /** heart rate reached after `driftSec` (models settling during calm breathing) */
  endBpm?: number;
  driftSec?: number;
  /** breaths per minute (drives RSA + amplitude modulation) */
  resp?: number;
  /** noise amplitude (camera units) */
  noise?: number;
  /** seconds of "finger arriving" before contact */
  arriveSec?: number;
  seed?: number;
}

/** Small deterministic PRNG so tests are repeatable. */
function mulberry32(a: number): () => number {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Physiologically shaped synthetic fingertip PPG (systolic peak, dicrotic notch,
 * respiratory sinus arrhythmia, baseline wander, sensor noise). Used by Demo mode
 * and by the unit tests. It goes through exactly the same pipeline as real frames.
 */
export class SyntheticPPG {
  private phase = 0;
  private rphase = 0;
  private t0 = -1;
  private last = 0;
  private rnd: () => number;
  constructor(private o: SynthOptions = {}) {
    this.rnd = mulberry32(o.seed ?? 7);
  }

  sample(tMs: number): FrameStats {
    const o = this.o;
    if (this.t0 < 0) {
      this.t0 = tMs;
      this.last = tMs;
    }
    const el = (tMs - this.t0) / 1000;
    const dt = Math.min(0.1, (tMs - this.last) / 1000);
    this.last = tMs;
    const arrive = o.arriveSec ?? 1.2;
    const b0 = o.bpm ?? 74;
    const b1 = o.endBpm ?? b0;
    const bpm = b0 + (b1 - b0) * Math.min(1, el / (o.driftSec ?? 25));
    this.rphase += (dt * (o.resp ?? 14)) / 60;
    const rsa = Math.sin(2 * Math.PI * this.rphase);
    this.phase += (dt * (bpm + 3.5 * rsa)) / 60;
    const p = this.phase % 1;
    // asymmetric systolic wave: fast upstroke, slower run-off, then notch + dicrotic bump
    const sys = p < 0.15 ? Math.exp(-(((p - 0.15) / 0.055) ** 2)) : Math.exp(-(((p - 0.15) / 0.17) ** 2));
    const w = sys + 0.3 * Math.exp(-(((p - 0.44) / 0.07) ** 2)) - 0.1 * Math.exp(-(((p - 0.35) / 0.03) ** 2));
    const amp = 1.6 * (1 + 0.22 * rsa);
    const noise = (this.rnd() - 0.5) * (o.noise ?? 0.35);
    const wander = 2.2 * Math.sin(el * 0.4) + 1.2 * Math.sin(el * 1.3);
    if (el < arrive) return { r: 40 + (el / arrive) * 140, g: 30, b: 28, sp: 40 - (el / arrive) * 30 };
    return {
      r: 196 + wander - w * amp * 1.9 + noise,
      g: 34 + wander * 0.3 - w * amp * 0.9 + noise * 0.5,
      b: 22 + noise * 0.3,
      sp: 9 + this.rnd() * 2,
    };
  }
}
