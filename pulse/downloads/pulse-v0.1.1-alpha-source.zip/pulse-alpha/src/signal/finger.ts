/** Classifies a camera frame summary: is a fingertip correctly covering the lens? */

export interface FrameStats {
  /** mean red, green, blue of the centre crop (0..255) */
  r: number;
  g: number;
  b: number;
  /** spatial standard deviation of red across the crop — high = scene detail visible */
  sp: number;
}

export type FingerState = 'ok' | 'dim' | 'nofinger' | 'dark' | 'partial' | 'saturated';

export function fingerState(s: FrameStats | null | undefined): FingerState {
  if (!s) return 'nofinger';
  const redDominant = s.r > 60 && s.r > s.g * 1.35 && s.r > s.b * 1.35;
  if (!redDominant) return s.r < 35 && s.g < 35 ? 'dark' : 'nofinger';
  if (s.sp > 28) return 'partial';
  if (s.r > 252 && s.g > 200) return 'saturated';
  if (s.r < 85) return 'dim';
  return 'ok';
}

/** Human guidance for each state. Short, calm, actionable. */
export const FINGER_HINT: Record<FingerState, string> = {
  ok: 'Good contact. Hold still.',
  dim: 'A bit dark. Turn your flashlight on or move to brighter light.',
  nofinger: 'Cover the rear camera and flash with one fingertip.',
  dark: 'Too dark to see your pulse. Turn the flashlight on, or face a bright lamp.',
  partial: 'Cover the whole lens. Slide your fingertip until the preview glows evenly red.',
  saturated: 'Too much light/pressure. Press more gently.',
};
