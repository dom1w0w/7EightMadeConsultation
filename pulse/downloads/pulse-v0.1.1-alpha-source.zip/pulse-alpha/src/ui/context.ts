import type { Settings, Store } from '../core/store';
import type { Haptics } from './haptics';

export interface Ctx {
  store: Store;
  haptics: Haptics;
  settings(): Settings;
  setSettings(p: Partial<Settings>): void;
  go(route: string): void;
  /** register cleanup for the current screen (stop camera, timers) */
  onLeave(fn: () => void): void;
}

export type Screen = (root: HTMLElement, ctx: Ctx, params: URLSearchParams) => void;
