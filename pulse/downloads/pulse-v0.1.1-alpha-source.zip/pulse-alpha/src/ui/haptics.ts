import type { Settings } from '../core/store';

/** Haptics via the Vibration API (Android/Chrome). iOS Safari has none — calls are no-ops there. */
export class Haptics {
  constructor(private settings: () => Settings) {}
  private buzz(p: number | number[]): void {
    if (!this.settings().haptics) return;
    try {
      navigator.vibrate?.(p);
    } catch {
      /* unsupported */
    }
  }
  tap(): void {
    this.buzz(8);
  }
  beat(): void {
    if (this.settings().beatHaptics) this.buzz(12);
  }
  success(): void {
    this.buzz([18, 60, 28]);
  }
  warn(): void {
    this.buzz([40, 50, 40]);
  }
  phase(): void {
    this.buzz(22);
  }
}
