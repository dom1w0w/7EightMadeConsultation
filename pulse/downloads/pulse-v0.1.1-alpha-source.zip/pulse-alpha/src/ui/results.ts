import type { CameraError } from '../engine/camera';
import type { FailReason } from '../core/reading';
import { frag, $ } from './dom';
import { icons } from './icons';

export function rangeNote(bpm: number): string {
  if (bpm < 50) return 'Lower than the typical resting range. Common in very fit people; if you feel unwell, talk to a clinician.';
  if (bpm < 60) return 'Just under the typical 60–100 resting range. Often seen in active people.';
  if (bpm <= 100) return 'Within the typical resting range of 60–100 bpm.';
  return 'Above the typical resting range. Were you just active, stressed or caffeinated? Rest a few minutes and re-check.';
}

export const DISCLAIMER = 'Wellness estimate. Not a medical device. Not for diagnosing or monitoring any condition.';

/** Failure / error state with specific, fixable guidance and a retry. */
export function renderProblem(root: HTMLElement, p: { fail?: FailReason; error?: CameraError }, actions: { retry: () => void }): void {
  let title = "We couldn't get a clear reading";
  let body: string;
  let tips: string[] = [
    'Cover the rear camera <b>and</b> flash completely with one fingertip.',
    'Press lightly. Pressing hard squeezes the blood out.',
    'Rest your hand on a table and stay still for 30 seconds.',
    'Cold hands read poorly. Warm them up first.',
  ];
  if (p.error) {
    switch (p.error.kind) {
      case 'denied':
        title = 'Camera access is off';
        body = 'Pulse needs the camera to see the color change in your fingertip. Video never leaves your phone.';
        tips = [
          '<b>iPhone:</b> Settings › Safari › Camera › Allow (or tap <b>aA</b> › Website Settings).',
          '<b>Android:</b> tap the lock icon by the address › Permissions › Camera › Allow.',
          'Then tap <b>Try again</b>.',
        ];
        break;
      case 'insecure':
        title = 'Open Pulse over https';
        body = 'Browsers only allow the camera on secure (https) pages or localhost.';
        tips = ['Use the https link you were given, or install the app.'];
        break;
      case 'notfound':
        title = 'No camera found';
        body =
          'This device has no usable camera. Open Pulse on your phone, or to see how it works here, turn on Settings › Demo mode (simulated readings).';
        tips = [];
        break;
      case 'busy':
        title = 'Camera is busy';
        body = 'Another app or tab is using the camera.';
        tips = ['Close other camera apps or tabs, then try again.'];
        break;
      case 'unsupported':
        title = "This browser can't use the camera";
        body = 'Open Pulse in Safari (iPhone) or Chrome (Android).';
        tips = [];
        break;
      default:
        body = p.error.message;
    }
  } else if (p.fail === 'timeout') {
    body = "The signal wasn't steady long enough. A few quick fixes usually solve it:";
  } else {
    body = 'The signal was too noisy to trust. Try once more with these tips:';
  }
  root.replaceChildren(
    frag(`<section class="stack fade-up" aria-labelledby="pb-t">
      <div class="center" style="padding-top:12px"><div class="flame" style="margin:0 auto 14px;background:rgba(239,90,76,.12);border-color:rgba(239,90,76,.4)"><span style="width:30px;color:var(--bad);display:block">${p.error ? icons.camera : icons.alert}</span></div>
      <h1 id="pb-t" class="h2" style="font-size:28px">${title}</h1><p class="lede">${body}</p></div>
      ${tips.length ? `<div class="card"><ul style="margin:0;padding-left:18px;display:grid;gap:8px;color:var(--muted)">${tips.map((t) => `<li>${t}</li>`).join('')}</ul></div>` : ''}
      <button class="btn block" type="button" data-retry>${icons.refresh} Try again</button>
    </section>`),
  );
  $('[data-retry]', root).addEventListener('click', actions.retry);
}
