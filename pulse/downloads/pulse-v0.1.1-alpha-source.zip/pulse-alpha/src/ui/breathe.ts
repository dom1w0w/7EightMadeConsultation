import { frag, $ } from './dom';
import type { Haptics } from './haptics';

export interface BreatheOptions {
  seconds?: number;
  inhale?: number;
  exhale?: number;
  haptics: Haptics;
}

const R = 47;
const C = 2 * Math.PI * R;

/** 60 s paced breathing (4 s in / 6 s out = 6 breaths per minute). Resolves true when finished, false if skipped. */
export function runBreathe(root: HTMLElement, o: BreatheOptions): Promise<boolean> {
  const total = (o.seconds ?? 60) * 1000;
  const inh = (o.inhale ?? 4) * 1000;
  const exh = (o.exhale ?? 6) * 1000;
  const cyc = inh + exh;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  root.replaceChildren(
    frag(`<section class="stack fade-up" aria-labelledby="b-t">
      <div class="center"><p class="eyebrow" style="color:var(--calm)">Step 2 of 3 · Breathe</p>
      <h1 id="b-t" class="h2" style="font-size:28px">Follow the circle</h1>
      <p class="lede" style="margin-top:6px">In through your nose as it grows, slowly out as it shrinks.</p></div>
      <div class="breath">
        <div class="halo" data-halo></div>
        <svg class="ring" viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="${R}" fill="none" stroke="#2a2520" stroke-width="1.6"/>
          <circle data-ring cx="50" cy="50" r="${R}" fill="none" stroke="#6fd3c1" stroke-width="2" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C}"/></svg>
        <div class="disc" data-disc></div>
        <div class="word" data-word aria-hidden="true">In</div>
      </div>
      <p class="center" style="margin:0"><span class="h2" data-cue role="status" aria-live="polite">Breathe in</span><br><span class="muted small" data-left>60s left</span></p>
      <button class="btn ghost block" type="button" data-skip>Skip to second reading</button>
    </section>`),
  );
  const disc = $('[data-disc]', root);
  const halo = $('[data-halo]', root);
  const ring = $('[data-ring]', root) as unknown as SVGCircleElement;
  const word = $('[data-word]', root);
  const cue = $('[data-cue]', root);
  const left = $('[data-left]', root);
  return new Promise((resolve) => {
    const t0 = performance.now();
    let raf = 0;
    let phase = '';
    let done = false;
    const end = (ok: boolean) => {
      if (done) return;
      done = true;
      cancelAnimationFrame(raf);
      document.removeEventListener('visibilitychange', vis);
      resolve(ok);
    };
    const vis = () => {
      if (document.hidden) end(false);
    };
    document.addEventListener('visibilitychange', vis);
    const frame = (t: number) => {
      const el = t - t0;
      if (!root.isConnected) return end(false);
      if (el >= total) {
        o.haptics.success();
        return end(true);
      }
      const c = el % cyc;
      const inhaling = c < inh;
      const p = inhaling ? c / inh : 1 - (c - inh) / exh;
      const e = 0.5 - 0.5 * Math.cos(Math.PI * p); // ease in-out
      const sc = reduce ? 1 : 0.62 + e * 0.68;
      disc.style.transform = `scale(${sc})`;
      halo.style.transform = `scale(${0.7 + e * 0.35})`;
      halo.style.opacity = String(0.45 + e * 0.55);
      ring.style.strokeDashoffset = String(C * (1 - el / total));
      const ph = inhaling ? 'in' : 'out';
      if (ph !== phase) {
        phase = ph;
        o.haptics.phase();
        word.textContent = inhaling ? 'In' : 'Out';
        cue.textContent = inhaling ? 'Breathe in' : 'Breathe out';
      }
      left.textContent = `${Math.ceil((total - el) / 1000)}s left`;
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    $('[data-skip]', root).addEventListener('click', () => end(true));
  });
}
