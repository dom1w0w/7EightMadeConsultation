import { Monitor } from '../engine/monitor';
import { CameraError } from '../engine/camera';
import { ReadingSession, qualityLabel, type FailReason, type ReadingResult } from '../core/reading';
import { FINGER_HINT } from '../signal/finger';
import type { LiveState } from '../signal/processor';
import type { SynthOptions } from '../signal/synth';
import type { BreathingEstimate } from '../signal/breathing';
import type { Haptics } from './haptics';
import { frag, $ } from './dom';
import { icons } from './icons';
import { WaveView, snapshot } from './wave';
import { platform, torchTip } from './platform';

export type ReaderOutcome =
  | { kind: 'done'; result: ReadingResult; breathing: BreathingEstimate | null; wave: number[]; demo: boolean }
  | { kind: 'fail'; reason: FailReason }
  | { kind: 'error'; error: CameraError }
  | { kind: 'cancel' };

export interface ReaderOptions {
  demo: boolean;
  demoSignal?: SynthOptions;
  haptics: Haptics;
  seconds?: number;
  heading?: string;
}

const R = 46; // ring radius in viewBox units (100)
const CIRC = 2 * Math.PI * R;

function message(s: LiveState): { text: string; tone: 'ok' | 'warn' } {
  switch (s.status) {
    case 'ok':
      return { text: 'Reading your pulse. Keep still.', tone: 'ok' };
    case 'starting':
    case 'locking':
      return { text: 'Finding your pulse. Hold still…', tone: 'ok' };
    case 'weak':
      return { text: 'Weak signal. Press lightly and relax your hand.', tone: 'warn' };
    case 'motion':
      return { text: 'Movement detected. Hold still (paused).', tone: 'warn' };
    default:
      return { text: FINGER_HINT[s.status], tone: 'warn' };
  }
}

/** Mounts a live reading UI into `root`, runs one reading, resolves with the outcome. */
export function runReader(root: HTMLElement, o: ReaderOptions): Promise<ReaderOutcome> {
  const seconds = o.seconds ?? 30;
  root.replaceChildren(
    frag(`<section class="reader fade-up" aria-label="${o.heading ?? 'Live reading'}">
      <h1 class="sr-only">${o.heading ?? 'Live reading'}</h1>
      <div class="dial">
        ${o.demo ? '<div class="demo-lens" aria-hidden="true"></div>' : '<video muted playsinline aria-hidden="true"></video>'}
        <div class="shade"></div>
        <svg class="ring" viewBox="0 0 100 100" aria-hidden="true">
          <defs><linearGradient id="gEmber" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff9a5c"/><stop offset="1" stop-color="#d2452f"/></linearGradient></defs>
          <circle class="track" cx="50" cy="50" r="${R}" fill="none" stroke-width="3.2"/>
          <circle class="prog" cx="50" cy="50" r="${R}" fill="none" stroke-width="3.6" stroke-linecap="round" stroke-dasharray="${CIRC}" stroke-dashoffset="${CIRC}"/>
        </svg>
        <div class="readout"><div class="bpm-big" data-bpm>--</div><div class="bpm-unit"><span class="heart-tick">♥</span> bpm</div></div>
      </div>
      <div class="status" role="status" aria-live="polite" data-status>Starting camera…</div>
      <div class="qual"><span class="qbars" data-level="0" aria-hidden="true"><i></i><i></i><i></i><i></i></span><span data-qtext>Signal: waiting</span><span aria-hidden="true">·</span><span class="timeleft" data-left>${seconds}s left</span></div>
      <div class="card wave-card"><span class="label">Live pulse wave</span><canvas aria-hidden="true"></canvas></div>
      <div data-notice></div>
      <div class="row" data-controls>
        <button class="btn ghost" data-cancel type="button">${icons.x} Cancel</button>
      </div>
    </section>`),
  );
  const $bpm = $('[data-bpm]', root);
  const $status = $('[data-status]', root);
  const $q = $('.qbars', root);
  const $qt = $('[data-qtext]', root);
  const $left = $('[data-left]', root);
  const $prog = $('.prog', root) as unknown as SVGCircleElement;
  const $tick = $('.heart-tick', root);
  const $notice = $('[data-notice]', root);
  const $controls = $('[data-controls]', root);
  const wave = new WaveView($('canvas', root) as HTMLCanvasElement);
  const video = root.querySelector('video') ?? document.createElement('video');
  const session = new ReadingSession(seconds);
  let lastMsg = '';
  let wasOk = false;
  let lastWarnBuzz = 0;
  let readingStart = 0;

  return new Promise<ReaderOutcome>((resolve) => {
    let settled = false;
    const finish = (out: ReaderOutcome) => {
      if (settled) return;
      settled = true;
      monitor.stop();
      document.removeEventListener('visibilitychange', onVis);
      resolve(out);
    };
    const onVis = () => {
      if (document.hidden) finish({ kind: 'cancel' });
    };
    document.addEventListener('visibilitychange', onVis);

    const monitor = new Monitor({
      video,
      demo: o.demo,
      demoSignal: o.demoSignal,
      onBeat: () => {
        $tick.classList.add('on');
        setTimeout(() => $tick.classList.remove('on'), 130);
        o.haptics.beat();
      },
      onState: (s, m) => {
        if (!readingStart) readingStart = s.now;
        const p = session.update(s);
        wave.draw(m.processor.wave(6000), s.status !== 'nofinger' && s.status !== 'dark');
        $prog.style.strokeDashoffset = String(CIRC * (1 - p.progress));
        $bpm.textContent = s.bpm && (s.status === 'ok' || s.status === 'weak' || s.status === 'motion') ? String(s.bpm) : '--';
        const level = s.quality >= 0.75 ? 4 : s.quality >= 0.6 ? 3 : s.quality >= 0.45 ? 2 : s.quality > 0 ? 1 : 0;
        $q.dataset.level = String(level);
        $qt.textContent = s.quality > 0 ? `Signal: ${qualityLabel(s.quality)}` : 'Signal: waiting';
        $left.textContent = p.phase === 'paused' ? `Paused · ${p.secondsLeft}s left` : `${p.secondsLeft}s left`;
        const msg = message(s);
        if (msg.text !== lastMsg) {
          lastMsg = msg.text;
          $status.textContent = msg.text;
          $status.dataset.tone = msg.tone;
        }
        const ok = s.status === 'ok';
        if (wasOk && !ok && s.now - lastWarnBuzz > 4000) {
          o.haptics.warn();
          lastWarnBuzz = s.now;
        }
        wasOk = ok;
        if (p.phase === 'done' && p.result) {
          o.haptics.success();
          const since = performance.now() - (p.result.seconds + 2) * 1000;
          finish({
            kind: 'done',
            result: p.result,
            breathing: m.processor.breathing(since),
            wave: snapshot(m.processor.wave(5000)),
            demo: o.demo,
          });
        } else if (p.phase === 'failed') {
          o.haptics.warn();
          finish({ kind: 'fail', reason: p.reason ?? 'timeout' });
        }
      },
    });

    $('[data-cancel]', root).addEventListener('click', () => finish({ kind: 'cancel' }));

    monitor
      .start()
      .then(() => {
        if (o.demo) {
          $notice.replaceChildren(
            frag(
              `<div class="notice info">${icons.info}<div><b>Demo mode: simulated signal.</b> This is not your pulse. It's for presenting without a camera. Turn it off in Settings to read your real pulse.</div></div>`,
            ),
          );
        } else if (monitor.info.torchCapable) {
          const b = frag(`<button class="btn ghost" type="button" data-torch aria-pressed="true">${icons.flash} Flash on</button>`);
          $controls.prepend(b);
          const tb = $('[data-torch]', root);
          tb.addEventListener('click', async () => {
            await monitor.setTorch(!monitor.info.torchOn);
            tb.setAttribute('aria-pressed', String(monitor.info.torchOn));
            tb.innerHTML = `${icons.flash} Flash ${monitor.info.torchOn ? 'on' : 'off'}`;
          });
        } else {
          const tip = torchTip(platform());
          $notice.replaceChildren(
            frag(`<div class="notice" data-torch-tip>${icons.flash}<div><b>${tip.title}</b> ${tip.body}</div></div>`),
          );
        }
      })
      .catch((e: unknown) => {
        finish({ kind: 'error', error: e instanceof CameraError ? e : new CameraError('unknown', String(e)) });
      });
  });
}
