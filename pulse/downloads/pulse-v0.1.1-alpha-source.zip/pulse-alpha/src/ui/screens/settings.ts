import type { Screen } from '../context';
import { frag, $, confirmDialog, toast } from '../dom';
import { icons } from '../icons';
import { DISCLAIMER } from '../results';

declare const __APP_VERSION__: string;
declare const __BUILD_DATE__: string;

export const settingsScreen: Screen = (root, ctx) => {
  const s = ctx.settings();
  const sw = (key: string, on: boolean, label: string, hint: string) => `
    <label class="setting" for="sw-${key}"><span class="txt">${label}<small>${hint}</small></span>
    <span class="switch"><input type="checkbox" role="switch" id="sw-${key}" data-key="${key}" ${on ? 'checked' : ''}/><span></span></span></label>`;
  const vib = 'vibrate' in navigator;
  root.replaceChildren(
    frag(`<section class="screen" aria-labelledby="st-t">
      <p class="eyebrow">Settings</p><h1 id="st-t" style="margin-bottom:18px">Settings</h1>
      <div class="group"><h2 class="group-h">Reading</h2>
        ${sw('haptics', s.haptics, 'Haptics', vib ? 'Gentle taps for start, finish and breathing cues.' : "Your browser doesn't support vibration (iPhone Safari). Turn on for Android.")}
        ${sw('beatHaptics', s.beatHaptics, 'Feel each beat', 'A tiny tap on every detected heartbeat while reading.')}
        ${sw('demo', s.demo, 'Demo mode', 'Simulated signal for presenting without a camera. Off = your real pulse.')}
      </div>
      <div class="group"><h2 class="group-h">Data</h2>
        <button class="setting" type="button" data-export><span class="txt">Export my readings<small>Download a CSV of your history.</small></span>${icons.download}</button>
        <button class="setting danger" type="button" data-clear><span class="txt">Clear all data<small>Deletes every reading and setting on this phone.</small></span>${icons.trash}</button>
      </div>
      <div class="group"><h2 class="group-h">Help</h2>
        <button class="setting" type="button" data-intro><span class="txt">Replay the intro<small>How to place your finger, privacy, and limits.</small></span>${icons.info}</button>
      </div>
      <div class="group"><h2 class="group-h">Privacy</h2><div class="prose">
        <p><b style="color:var(--ink)">Everything stays on your phone.</b> The camera feed is analyzed live on your device and never recorded, uploaded or sent anywhere. Readings are stored only in this browser. No accounts, no ads, no tracking.</p>
        <p>Clearing your browser data or tapping <b>Clear all data</b> removes them permanently.</p></div></div>
      <div class="group"><h2 class="group-h">Not a medical device</h2><div class="prose">
        <p>${DISCLAIMER}</p>
        <p>Pulse estimates heart rate from tiny color changes in your fingertip (photoplethysmography). Breathing rate is estimated from the rhythm of your pulse. Results can be affected by movement, light, skin temperature and pressure. Pulse does <b>not</b> measure blood oxygen or blood pressure.</p>
        <p>If you feel unwell, or have chest pain, fainting or shortness of breath, contact a medical professional or emergency services.</p></div></div>
      <div class="group"><h2 class="group-h">About</h2><div class="prose">
        <p><b style="color:var(--ink)">Pulse by 7EightMade</b> · <span class="badge badge-alpha">Demo build · Alpha</span><br>Early preview. Version ${__APP_VERSION__} · built ${__BUILD_DATE__}</p>
        <p class="serif-i" style="color:var(--ink);font-size:17px">Fall down 7, stand up 8.</p>
        <p>Works offline once loaded<span data-offline-ready></span>. Add it to your home screen for the full-screen app.</p></div></div>
    </section>`),
  );
  void navigator.serviceWorker?.getRegistration().then((r) => {
    const el = root.querySelector('[data-offline-ready]');
    if (el && r?.active) el.textContent = ' (offline cache ready on this device)';
  });
  root.querySelectorAll<HTMLInputElement>('input[data-key]').forEach((i) =>
    i.addEventListener('change', () => {
      ctx.setSettings({ [i.dataset.key!]: i.checked });
      if (i.checked) ctx.haptics.tap();
      if (i.dataset.key === 'demo') toast(i.checked ? 'Demo mode on: simulated signal' : 'Demo mode off: real camera');
    }),
  );
  $('[data-intro]', root).addEventListener('click', () => {
    ctx.setSettings({ onboarded: false });
    ctx.go('measure');
  });
  $('[data-export]', root).addEventListener('click', () => {
    const rs = ctx.store.readings();
    if (!rs.length) return toast('No readings to export yet');
    const csv = ['time,bpm,breaths_per_min,signal_quality,type,demo,before_bpm']
      .concat(rs.map((r) => [new Date(r.at).toISOString(), r.bpm, r.breathing ?? '', r.quality, r.kind, r.demo, r.before ?? ''].join(',')))
      .join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = 'pulse-readings.csv';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  });
  $('[data-clear]', root).addEventListener('click', async () => {
    if (
      await confirmDialog(
        'Clear all data?',
        'Every reading, your streak and settings will be deleted from this phone. This cannot be undone.',
        'Clear everything',
        true,
      )
    ) {
      ctx.store.clearAll();
      toast('All data cleared');
      ctx.go('measure');
    }
  });
};
