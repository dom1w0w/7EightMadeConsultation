import type { Screen } from '../context';
import { runReader, type ReaderOutcome } from '../reader';
import { runBreathe } from '../breathe';
import { frag, $, animateNumber } from '../dom';
import { icons } from '../icons';
import { DISCLAIMER, renderProblem } from '../results';

type Done = Extract<ReaderOutcome, { kind: 'done' }>;

const breaths = (a: Done, b: Done): string =>
  a.breathing && b.breathing
    ? `${a.breathing.rate} → ${b.breathing.rate}`
    : b.breathing
      ? String(b.breathing.rate)
      : a.breathing
        ? String(a.breathing.rate)
        : '—';

export const calmScreen: Screen = (root, ctx) => {
  let alive = true;
  ctx.onLeave(() => {
    alive = false;
    root.dispatchEvent(new Event('leave'));
  });
  const leave = () => new Promise<null>((r) => root.addEventListener('leave', () => r(null), { once: true }));
  // demo: a stressed-ish start that settles with slow breathing
  const demoStart = 80 + Math.round(Math.random() * 8);

  const steps = (n: number) =>
    `<div class="steps" aria-hidden="true">${[1, 2, 3].map((i) => `<i class="${i <= n ? 'on' : ''}"></i>`).join('')}</div>`;

  const intro = () => {
    root.replaceChildren(
      frag(`<section class="screen stack" aria-labelledby="c-t">
        <div class="center"><p class="eyebrow" style="color:var(--calm)">2-minute reset</p><h1 id="c-t">Calm check</h1>
        <p class="lede">See what one minute of slow breathing does to your heart rate.</p></div>
        <div class="breath" style="width:min(58vw,220px)" aria-hidden="true"><div class="halo"></div><div class="disc" style="transform:scale(.9);animation:beat 4s ease-in-out infinite"></div></div>
        <ol class="card" style="margin:0;padding:16px 16px 16px 36px;display:grid;gap:8px;color:var(--muted)">
          <li><b style="color:var(--ink)">Reading 1</b> · 30 seconds, finger on camera</li>
          <li><b style="color:var(--ink)">Breathe</b> · 60 seconds of guided slow breathing</li>
          <li><b style="color:var(--ink)">Reading 2</b> · 30 seconds, see the change</li>
        </ol>
        <button class="btn calm block" type="button" data-go>${icons.calm} Begin calm check</button>
        ${ctx.settings().demo ? '<p class="small muted center" style="margin:0"><span class="tag demo">Demo</span> Demo mode is on: readings are simulated.</p>' : ''}
        <p class="disclaimer">${DISCLAIMER}</p>
      </section>`),
    );
    $('[data-go]', root).addEventListener('click', () => {
      ctx.haptics.tap();
      void flow();
    });
  };

  const read = async (label: string, n: number, demoSignal: { bpm: number; endBpm?: number; resp: number }): Promise<Done | null> => {
    for (;;) {
      const host = document.createElement('div');
      root.replaceChildren(
        frag(`<div class="center">${steps(n)}<p class="eyebrow" style="color:var(--calm)">Step ${n} of 3 · ${label}</p></div>`),
        host,
      );
      const out = await Promise.race([
        runReader(host, { demo: ctx.settings().demo, haptics: ctx.haptics, demoSignal, heading: label }),
        leave(),
      ]);
      if (!alive || !out || out.kind === 'cancel') return null;
      if (out.kind === 'done') return out;
      const again = await new Promise<boolean>((res) =>
        renderProblem(root, out.kind === 'fail' ? { fail: out.reason } : { error: out.error }, {
          retry: () => res(true),
        }),
      );
      if (!again) return null;
    }
  };

  const flow = async () => {
    const a = await read('First reading', 1, { bpm: demoStart, resp: 16 });
    if (!a) return alive && intro();
    const host = document.createElement('div');
    root.replaceChildren(frag(`<div class="center">${steps(2)}</div>`), host);
    const breathed = await Promise.race([runBreathe(host, { haptics: ctx.haptics }), leave()]);
    if (!alive || breathed === null) return;
    const b = await read('Second reading', 3, { bpm: demoStart - 7, endBpm: demoStart - 12, resp: 7 });
    if (!b) return alive && intro();
    const now = Date.now();
    ctx.store.add({
      at: now - 1,
      bpm: a.result.bpm,
      breathing: a.breathing?.rate ?? null,
      quality: a.result.quality,
      kind: 'calm-before',
      demo: a.demo,
      wave: a.wave,
    });
    const rec = ctx.store.add({
      at: now,
      bpm: b.result.bpm,
      breathing: b.breathing?.rate ?? null,
      quality: b.result.quality,
      kind: 'calm-after',
      demo: b.demo,
      before: a.result.bpm,
      wave: b.wave,
    });
    result(a, b, rec.id);
  };

  const result = (a: Done, b: Done, id: string) => {
    const d = a.result.bpm - b.result.bpm;
    const headline = d >= 3 ? `Down ${d} bpm` : d > 0 ? `Down ${d}` : d === 0 ? 'Holding steady' : `Up ${-d}`;
    const note =
      d >= 3
        ? 'Slow breathing nudged your body toward rest. Nice work.'
        : d > 0
          ? 'A small dip. Calm builds with practice; try it daily.'
          : "No drop this time. That's normal; talking, posture and caffeine all play a part.";
    root.replaceChildren(
      frag(`<section class="screen stack" aria-labelledby="cr-t">
        <div class="center">${steps(3)}<p class="eyebrow" style="color:var(--calm)">Calm check result${a.demo ? ' <span class="tag demo">Demo mode · simulated</span>' : ''}</p>
        <h1 id="cr-t" class="delta pop">${headline}</h1><p class="lede" style="margin-top:6px">${note}</p></div>
        <div class="compare" role="group" aria-label="Before ${a.result.bpm}, after ${b.result.bpm} beats per minute">
          <div class="side fade-up"><div class="k small muted">BEFORE</div><div class="num" data-a>${a.result.bpm}</div><div class="small muted">bpm</div></div>
          <span class="arrow" aria-hidden="true">${icons.arrow}</span>
          <div class="side fade-up" style="animation-delay:.15s;border-color:rgba(111,211,193,.45)"><div class="k small muted">AFTER</div><div class="num" style="color:var(--calm)" data-b>${b.result.bpm}</div><div class="small muted">bpm</div></div>
        </div>
        <div class="metrics" style="grid-template-columns:1fr 1fr">
          <div class="metric"><div class="v">${breaths(a, b)}</div><div class="k">Breaths/min${a.breathing && b.breathing ? '' : b.breathing ? ' after' : ''}</div></div>
          <div class="metric"><div class="v">60s</div><div class="k">Slow breathing</div></div>
        </div>
        <a class="btn calm block" href="#/share?id=${id}">${icons.share} Share my calm check</a>
        <div class="row"><button class="btn ghost" type="button" data-again>${icons.refresh} Again</button><a class="btn ghost" href="#/history">${icons.history} History</a></div>
        <p class="disclaimer">${DISCLAIMER}</p>
      </section>`),
    );
    animateNumber($('[data-a]', root), a.result.bpm);
    animateNumber($('[data-b]', root), b.result.bpm, 1200);
    $('[data-again]', root).addEventListener('click', () => void flow());
  };

  intro();
};
