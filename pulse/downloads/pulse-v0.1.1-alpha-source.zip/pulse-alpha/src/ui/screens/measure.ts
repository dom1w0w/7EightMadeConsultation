import type { Screen, Ctx } from '../context';
import { runReader, type ReaderOutcome } from '../reader';
import { frag, $, animateNumber, toast } from '../dom';
import { icons } from '../icons';
import { qualityLabel } from '../../core/reading';
import { DISCLAIMER, rangeNote, renderProblem } from '../results';

export const measureScreen: Screen = (root, ctx) => {
  let alive = true;
  ctx.onLeave(() => {
    alive = false;
    root.dispatchEvent(new Event('leave'));
  });

  const idle = () => {
    const demo = ctx.settings().demo;
    root.replaceChildren(
      frag(`<section class="hero screen" aria-labelledby="m-t">
        <p class="eyebrow">30-second check</p>
        <h1 id="m-t">Check your pulse</h1>
        <p class="lede">Place a fingertip over your phone's rear camera. Pulse reads the tiny color change with each heartbeat.</p>
        <div class="orb" aria-hidden="true"><div class="orb-core">${icons.heartFill}</div></div>
        <button class="btn block" type="button" data-start>${icons.pulse} Start reading</button>
        <div class="tips" role="list">
          <div class="tip" role="listitem">${icons.finger}Cover camera + flash</div>
          <div class="tip" role="listitem">${icons.flash}Flashlight on</div>
          <div class="tip" role="listitem">${icons.still}Rest &amp; stay still</div>
        </div>
        ${
          demo
            ? `<div class="notice info" style="margin-top:10px">${icons.info}<div><b>Demo mode is on.</b> Readings are simulated. <button class="linkbtn" style="padding:0;color:#c9d7ff" type="button" data-demo-off>Turn off</button></div></div>`
            : ''
        }
        <p class="disclaimer">${DISCLAIMER}</p>
      </section>`),
    );
    $('[data-start]', root).addEventListener('click', () => {
      ctx.haptics.tap();
      void measure();
    });
    root.querySelector('[data-demo-off]')?.addEventListener('click', () => {
      ctx.setSettings({ demo: false });
      toast('Demo mode off: real camera');
      idle();
    });
  };

  const measure = async () => {
    const demo = ctx.settings().demo;
    const leave = new Promise<ReaderOutcome>((r) => root.addEventListener('leave', () => r({ kind: 'cancel' }), { once: true }));
    const out = await Promise.race([
      runReader(root, {
        demo,
        haptics: ctx.haptics,
        demoSignal: { bpm: 66 + Math.round(Math.random() * 12), resp: 12 + Math.round(Math.random() * 4) },
      }),
      leave,
    ]);
    if (!alive) return;
    if (out.kind === 'cancel') return idle();
    if (out.kind === 'fail' || out.kind === 'error') {
      return renderProblem(root, out.kind === 'fail' ? { fail: out.reason } : { error: out.error }, {
        retry: () => void measure(),
      });
    }
    const rec = ctx.store.add({
      at: Date.now(),
      bpm: out.result.bpm,
      breathing: out.breathing?.rate ?? null,
      quality: Math.round(out.result.quality * 100) / 100,
      kind: 'measure',
      demo: out.demo,
      wave: out.wave,
    });
    result(rec.id, out);
  };

  const result = (id: string, out: Extract<ReaderOutcome, { kind: 'done' }>) => {
    const { bpm, quality } = out.result;
    root.replaceChildren(
      frag(`<section class="result screen" aria-labelledby="r-t">
        <h1 class="eyebrow" id="r-t" style="font-family:var(--sans);font-size:11px;letter-spacing:.2em">Your reading${out.demo ? ' <span class="tag demo">Demo mode · simulated</span>' : ''}</h1>
        <div><div class="big pop" data-num aria-hidden="true">${bpm}</div>
          <div class="bpm-unit">beats per minute</div>
          <p class="sr-only" role="status">Your heart rate estimate is ${bpm} beats per minute.</p></div>
        <p class="muted" style="margin:0">${rangeNote(bpm)}</p>
        <div class="metrics">
          <div class="metric fade-up" style="animation-delay:.1s"><div class="v">${out.breathing ? out.breathing.rate : '—'}</div><div class="k">Breaths/min</div></div>
          <div class="metric fade-up" style="animation-delay:.18s"><div class="v">${qualityLabel(quality)}</div><div class="k">Signal</div></div>
          <div class="metric fade-up" style="animation-delay:.26s"><div class="v">${out.result.seconds}s</div><div class="k">Read time</div></div>
        </div>
        ${out.breathing ? '' : '<p class="small muted" style="margin:0">Breathing rate needs a very steady read. Stay extra still to get one.</p>'}
        <div class="stack">
          <a class="btn block" href="#/share?id=${id}">${icons.share} Make a share card</a>
          <div class="row"><a class="btn ghost" href="#/calm">${icons.calm} Calm check</a><button class="btn ghost" type="button" data-again>${icons.refresh} Again</button></div>
        </div>
        <p class="disclaimer">${DISCLAIMER} Breathing rate is an estimate from your pulse rhythm.</p>
      </section>`),
    );
    animateNumber($('[data-num]', root), bpm);
    $('[data-again]', root).addEventListener('click', () => void measure());
  };

  idle();
};

export type { Ctx };
