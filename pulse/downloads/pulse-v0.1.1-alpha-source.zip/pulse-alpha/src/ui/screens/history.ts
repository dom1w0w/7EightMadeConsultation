import type { Screen } from '../context';
import { frag, confirmDialog, toast } from '../dom';
import { icons, art } from '../icons';
import { dayKey, streak, type StoredReading } from '../../core/store';

function chart(rs: StoredReading[]): string {
  const pts = rs.slice(-20);
  if (pts.length < 2) return '<p class="small muted center" style="margin:30px 0">Your trend appears after two readings.</p>';
  const W = 320;
  const H = 150;
  const pad = 22;
  const vals = pts.map((r) => r.bpm);
  const lo = Math.min(...vals) - 5;
  const hi = Math.max(...vals) + 5;
  const x = (i: number) => pad + (i / (pts.length - 1)) * (W - pad * 2);
  const y = (v: number) => 12 + (1 - (v - lo) / (hi - lo)) * (H - 34);
  // smooth path (Catmull-Rom to Bezier)
  const P = pts.map((r, i) => [x(i), y(r.bpm)]);
  let d = `M${P[0][0]},${P[0][1]}`;
  for (let i = 0; i < P.length - 1; i++) {
    const p0 = P[Math.max(0, i - 1)];
    const p1 = P[i];
    const p2 = P[i + 1];
    const p3 = P[Math.min(P.length - 1, i + 2)];
    d += ` C${p1[0] + (p2[0] - p0[0]) / 6},${p1[1] + (p2[1] - p0[1]) / 6} ${p2[0] - (p3[0] - p1[0]) / 6},${p2[1] - (p3[1] - p1[1]) / 6} ${p2[0]},${p2[1]}`;
  }
  const area = `${d} L${P[P.length - 1][0]},${H - 18} L${P[0][0]},${H - 18} Z`;
  const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Heart rate trend of last ${pts.length} readings, from ${vals[0]} to ${vals[vals.length - 1]} bpm">
    <defs><linearGradient id="ga" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ee7a3c" stop-opacity=".35"/><stop offset="1" stop-color="#ee7a3c" stop-opacity="0"/></linearGradient>
    <linearGradient id="gl" x1="0" x2="1"><stop offset="0" stop-color="#d2452f"/><stop offset="1" stop-color="#ff9a5c"/></linearGradient></defs>
    <line x1="${pad}" x2="${W - pad}" y1="${y(avg)}" y2="${y(avg)}" stroke="#a69c90" stroke-opacity=".35" stroke-dasharray="3 5"/>
    <text x="${W - pad}" y="${y(avg) - 5}" text-anchor="end" font-size="9" fill="#a69c90">avg ${Math.round(avg)}</text>
    <path d="${area}" fill="url(#ga)"/>
    <path d="${d}" fill="none" stroke="url(#gl)" stroke-width="2.6" stroke-linecap="round" class="draw"/>
    ${P.map((p, i) => `<circle cx="${p[0]}" cy="${p[1]}" r="${i === P.length - 1 ? 4.5 : 2.6}" fill="${pts[i].kind === 'calm-after' ? '#6fd3c1' : '#ff9a5c'}"/>`).join('')}
    <text x="${pad}" y="${H - 3}" font-size="9" fill="#776e64">${new Date(pts[0].at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</text>
    <text x="${W - pad}" y="${H - 3}" font-size="9" fill="#776e64" text-anchor="end">${new Date(pts[pts.length - 1].at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</text>
  </svg>`;
}

export const historyScreen: Screen = (root, ctx) => {
  const render = () => {
    const rs = ctx.store.readings();
    const st = streak(rs);
    if (!rs.length) {
      root.replaceChildren(
        frag(`<section class="screen"><p class="eyebrow">History</p><h1>Your rhythm</h1>
          <div class="card empty" style="margin-top:18px">${art.empty}<h2>No readings yet</h2>
          <p class="muted" style="margin:0">Take your first 30-second reading to start a streak. Everything stays on this phone.</p>
          <a class="btn" href="#/measure" style="margin-top:8px">${icons.pulse} Take a reading</a></div></section>`),
      );
      return;
    }
    const days: string[] = [];
    const set = new Set(rs.map((r) => dayKey(r.at)));
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      days.push(
        `<div class="${set.has(dayKey(d.getTime())) ? 'on' : ''}"><i></i>${d.toLocaleDateString(undefined, { weekday: 'narrow' })}</div>`,
      );
    }
    const week = rs.filter((r) => Date.now() - r.at < 7 * 864e5);
    const avg = week.length ? Math.round(week.reduce((a, r) => a + r.bpm, 0) / week.length) : null;
    const low = Math.min(...rs.map((r) => r.bpm));
    const calms = rs.filter((r) => r.kind === 'calm-after' && r.before);
    const bestDrop = calms.length ? Math.max(...calms.map((r) => (r.before ?? r.bpm) - r.bpm)) : null;
    const list = [...rs]
      .reverse()
      .slice(0, 60)
      .map((r) => {
        const when = new Date(r.at);
        const kind =
          r.kind === 'calm-after'
            ? `<span class="tag calm">Calm ${r.before ? `${r.before}→${r.bpm}` : ''}</span>`
            : r.kind === 'calm-before'
              ? '<span class="tag calm">Calm · before</span>'
              : '';
        return `<div class="item" role="listitem"><div class="bpm">${r.bpm}<small>BPM</small></div>
          <div class="meta"><b>${when.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}</b> · ${when.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}${kind}${r.demo ? '<span class="tag demo">Demo</span>' : ''}<br>${r.breathing ? `${r.breathing} breaths/min` : 'Breathing: n/a'}</div>
          <div class="row" style="gap:6px"><a class="iconbtn" href="#/share?id=${r.id}" aria-label="Share reading of ${r.bpm} bpm">${icons.share}</a><button class="iconbtn" type="button" data-del="${r.id}" aria-label="Delete reading of ${r.bpm} bpm">${icons.trash}</button></div></div>`;
      })
      .join('');
    root.replaceChildren(
      frag(`<section class="screen stack" aria-labelledby="h-t">
        <div><p class="eyebrow">History</p><h1 id="h-t">Your rhythm</h1></div>
        <div class="card"><div class="streak"><div class="flame">${icons.flame}</div>
          <div><div class="n">${st.current} day${st.current === 1 ? '' : 's'}</div><div class="muted small">${st.today ? 'Streak alive. See you tomorrow.' : st.current ? 'Read today to keep your streak.' : 'Read today to start a streak.'} · Best ${st.best}</div></div></div>
          <div class="week" aria-label="Readings in the last 7 days">${days.join('')}</div></div>
        <div class="metrics">
          <div class="metric"><div class="v">${avg ?? '—'}</div><div class="k">7-day avg</div></div>
          <div class="metric"><div class="v">${low}</div><div class="k">Lowest</div></div>
          <div class="metric"><div class="v">${bestDrop !== null ? (bestDrop > 0 ? `−${bestDrop}` : '0') : '—'}</div><div class="k">Best calm drop</div></div>
        </div>
        <div class="card chart"><h2 style="font-size:16px;margin-bottom:6px">Trend</h2>${chart(rs)}</div>
        <h2 style="font-size:16px;margin-top:6px">Readings</h2>
        <div class="list" role="list">${list}</div>
        <p class="disclaimer">Stored only on this device. Wellness estimates, not medical measurements.</p>
      </section>`),
    );
    root.querySelectorAll<HTMLButtonElement>('[data-del]').forEach((b) =>
      b.addEventListener('click', async () => {
        if (await confirmDialog('Delete this reading?', 'This removes it from your history on this phone.', 'Delete', true)) {
          ctx.store.remove(b.dataset.del!);
          toast('Reading deleted');
          render();
        }
      }),
    );
  };
  render();
};
