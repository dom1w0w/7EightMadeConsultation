import type { Screen } from '../context';
import { frag, $, toast } from '../dom';
import { icons, art } from '../icons';
import { renderShareCard, MOTTO } from '../sharecard';
import markUrl from '../../assets/mark.svg?url';

export const shareScreen: Screen = (root, ctx, params) => {
  const all = ctx.store.readings();
  const id = params.get('id');
  const r = (id && all.find((x) => x.id === id)) || all[all.length - 1];
  if (!r) {
    root.replaceChildren(
      frag(`<section class="screen"><p class="eyebrow">Share</p><h1>Share card</h1>
      <div class="card empty" style="margin-top:18px">${art.empty}<h2>Nothing to share yet</h2><p class="muted" style="margin:0">Take a reading and Pulse turns it into a card you can post.</p>
      <a class="btn" href="#/measure">${icons.pulse} Take a reading</a></div></section>`),
    );
    return;
  }
  root.replaceChildren(
    frag(`<section class="screen stack" aria-labelledby="s-t">
      <div><p class="eyebrow">Share</p><h1 id="s-t">Your card</h1><p class="lede">${MOTTO}. Post it, send it, keep it.</p></div>
      <img class="share-preview" alt="Share card: ${r.bpm} bpm, ${new Date(r.at).toLocaleDateString()}" data-img />
      <button class="btn block" type="button" data-share disabled>${icons.share} Share</button>
      <button class="btn ghost block" type="button" data-dl disabled>${icons.download} Save image</button>
      <p class="disclaimer">Only the image is shared. Your history stays on this phone.</p>
    </section>`),
  );
  const img = $('[data-img]', root) as HTMLImageElement;
  const bShare = $('[data-share]', root) as HTMLButtonElement;
  const bDl = $('[data-dl]', root) as HTMLButtonElement;
  void (async () => {
    const cv = await renderShareCard(r, markUrl);
    const blob = await new Promise<Blob | null>((res) => cv.toBlob(res, 'image/png'));
    if (!blob || !root.isConnected) return;
    const url = URL.createObjectURL(blob);
    img.src = url;
    ctx.onLeave(() => URL.revokeObjectURL(url));
    const file = new File([blob], `pulse-${r.bpm}bpm.png`, { type: 'image/png' });
    const canShareFile = !!navigator.canShare?.({ files: [file] });
    bShare.disabled = false;
    bDl.disabled = false;
    if (!canShareFile && !navigator.share) bShare.hidden = true;
    bShare.addEventListener('click', async () => {
      ctx.haptics.tap();
      try {
        if (canShareFile) await navigator.share({ files: [file], title: 'My Pulse', text: `${r.bpm} bpm. ${MOTTO}.` });
        else await navigator.share({ title: 'My Pulse', text: `${r.bpm} bpm on Pulse by 7EightMade. ${MOTTO}.` });
      } catch (e) {
        if ((e as Error).name !== 'AbortError') toast("Couldn't open sharing. Use Save image instead");
      }
    });
    bDl.addEventListener('click', () => {
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      document.body.append(a);
      a.click();
      a.remove();
      toast('Image saved');
    });
  })();
};
