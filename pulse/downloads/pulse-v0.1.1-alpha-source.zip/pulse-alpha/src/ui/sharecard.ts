import type { StoredReading } from '../core/store';

export const MOTTO = 'Fall down 7, stand up 8';

/** Renders the branded 1080×1350 share card. Returns the canvas. */
export async function renderShareCard(r: StoredReading, markUrl: string): Promise<HTMLCanvasElement> {
  await document.fonts?.ready;
  const W = 1080;
  const H = 1350;
  const cv = document.createElement('canvas');
  cv.width = W;
  cv.height = H;
  const c = cv.getContext('2d')!;
  const calm = r.kind === 'calm-after' && r.before;
  const accent = calm ? '#6fd3c1' : '#ee7a3c';
  // background
  c.fillStyle = '#0e0d0c';
  c.fillRect(0, 0, W, H);
  let g = c.createRadialGradient(W * 0.5, -100, 50, W * 0.5, 0, 1100);
  g.addColorStop(0, calm ? 'rgba(111,211,193,0.30)' : 'rgba(238,122,60,0.34)');
  g.addColorStop(1, 'rgba(14,13,12,0)');
  c.fillStyle = g;
  c.fillRect(0, 0, W, H);
  g = c.createRadialGradient(W, H, 50, W, H, 900);
  g.addColorStop(0, 'rgba(47,107,255,0.16)');
  g.addColorStop(1, 'rgba(14,13,12,0)');
  c.fillStyle = g;
  c.fillRect(0, 0, W, H);
  // grain-free subtle grid
  c.strokeStyle = 'rgba(242,236,226,0.04)';
  c.lineWidth = 2;
  for (let x = 0; x < W; x += 90) {
    c.beginPath();
    c.moveTo(x, 0);
    c.lineTo(x, H);
    c.stroke();
  }
  // header: mark + wordmark
  try {
    const img = new Image();
    img.src = markUrl;
    await img.decode();
    c.drawImage(img, 80, 80, 88, 88);
  } catch {
    /* mark optional */
  }
  c.fillStyle = '#f2ece2';
  c.font = '600 64px Oswald, "Arial Narrow", sans-serif';
  c.textBaseline = 'alphabetic';
  c.fillText('PULSE', 196, 142);
  c.font = '600 22px Inter, sans-serif';
  c.fillStyle = '#a69c90';
  c.fillText('BY 7EIGHTMADE', 198, 172);
  // date chip
  const date = new Date(r.at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  c.font = '600 26px Inter, sans-serif';
  const dw = c.measureText(date).width + 48;
  c.strokeStyle = 'rgba(242,236,226,0.25)';
  c.lineWidth = 2;
  c.beginPath();
  c.roundRect(W - 80 - dw, 98, dw, 58, 29);
  c.stroke();
  c.fillStyle = '#f2ece2';
  c.fillText(date, W - 80 - dw + 24, 136);
  // label
  c.font = '600 28px Inter, sans-serif';
  c.fillStyle = accent;
  c.fillText(calm ? 'CALM CHECK' : 'HEART RATE', 80, 330);
  // big number
  const bg = c.createLinearGradient(0, 360, 0, 640);
  bg.addColorStop(0, '#fff1e4');
  bg.addColorStop(1, accent);
  c.fillStyle = bg;
  c.font = '600 300px Oswald, "Arial Narrow", sans-serif';
  c.fillText(String(r.bpm), 70, 630);
  const nw = c.measureText(String(r.bpm)).width;
  c.font = '600 44px Inter, sans-serif';
  c.fillStyle = '#a69c90';
  c.fillText('BPM', 70 + nw + 24, 630);
  if (calm) {
    c.font = '500 48px Oswald, sans-serif';
    c.fillStyle = '#6fd3c1';
    const d = (r.before ?? r.bpm) - r.bpm;
    c.fillText(d > 0 ? `↓ ${d} BPM AFTER 60s OF BREATHING (FROM ${r.before})` : `FROM ${r.before} BPM · 60s OF BREATHING`, 80, 720);
  } else if (r.breathing) {
    c.font = '500 48px Oswald, sans-serif';
    c.fillStyle = '#f2ece2';
    c.fillText(`${r.breathing} BREATHS / MIN`, 80, 720);
  }
  // waveform
  const wave =
    r.wave && r.wave.length > 10
      ? r.wave
      : Array.from(
          { length: 140 },
          (_, i) => Math.exp(-(((i % 28) - 6) ** 2) / 8) * 0.95 - 0.2 + 0.35 * Math.exp(-(((i % 28) - 14) ** 2) / 10),
        );
  const top = 790;
  const wh = 260;
  const lg = c.createLinearGradient(80, 0, W - 80, 0);
  lg.addColorStop(0, 'rgba(210,69,47,0.15)');
  lg.addColorStop(0.4, calm ? '#3aa996' : '#d2452f');
  lg.addColorStop(1, calm ? '#b6f3e8' : '#ff9a5c');
  c.strokeStyle = lg;
  c.lineWidth = 8;
  c.lineJoin = 'round';
  c.lineCap = 'round';
  c.shadowColor = calm ? 'rgba(111,211,193,0.6)' : 'rgba(238,122,60,0.6)';
  c.shadowBlur = 28;
  c.beginPath();
  wave.forEach((v, i) => {
    const x = 80 + (i / (wave.length - 1)) * (W - 160);
    const y = top + wh / 2 - v * (wh / 2 - 12);
    if (i) c.lineTo(x, y);
    else c.moveTo(x, y);
  });
  c.stroke();
  c.shadowBlur = 0;
  // motto
  c.fillStyle = '#f2ece2';
  c.font = 'italic 500 64px Fraunces, Georgia, serif';
  c.fillText(MOTTO + '.', 80, 1170);
  // footer
  c.fillStyle = 'rgba(242,236,226,0.12)';
  c.fillRect(80, 1210, W - 160, 2);
  c.font = '500 24px Inter, sans-serif';
  c.fillStyle = '#776e64';
  c.fillText(`${r.demo ? 'DEMO READING · ' : ''}Wellness estimate · not a medical device`, 80, 1262);
  c.textAlign = 'right';
  c.fillStyle = '#a69c90';
  c.fillText('7eightmade', W - 80, 1262);
  c.textAlign = 'left';
  return cv;
}
