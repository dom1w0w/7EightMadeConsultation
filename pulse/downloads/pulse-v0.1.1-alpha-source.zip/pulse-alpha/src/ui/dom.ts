/** Tiny DOM helpers — no framework needed for an app this size. */
export function h<K extends keyof HTMLElementTagNameMap>(
  tag: K,
  attrs: Record<string, string | number | boolean | EventListener | undefined> = {},
  ...kids: (Node | string | null | undefined | false)[]
): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === false) continue;
    if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v as EventListener);
    else if (k === 'html') el.innerHTML = String(v);
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  for (const c of kids) if (c !== null && c !== undefined && c !== false) el.append(c);
  return el;
}

/** Parse trusted, static HTML (templates in this codebase only — never user data). */
export function frag(html: string): DocumentFragment {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content;
}

export function $(sel: string, root: ParentNode = document): HTMLElement {
  const el = root.querySelector(sel);
  if (!el) throw new Error(`missing ${sel}`);
  return el as HTMLElement;
}

export const esc = (s: string): string =>
  s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

export function animateNumber(el: HTMLElement, to: number, ms = 900): void {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce) {
    el.textContent = String(to);
    return;
  }
  const t0 = performance.now();
  const from = Math.max(0, to - 40);
  const tick = (t: number) => {
    const p = Math.min(1, (t - t0) / ms);
    const e = 1 - Math.pow(1 - p, 3);
    el.textContent = String(Math.round(from + (to - from) * e));
    if (p < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

let toastTimer = 0;
export function toast(msg: string): void {
  let el = document.querySelector<HTMLElement>('.toast');
  if (!el) {
    el = h('div', { class: 'toast', role: 'status', 'aria-live': 'polite' });
    document.body.append(el);
  }
  el.textContent = msg;
  el.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => el!.classList.remove('on'), 2600);
}

export function confirmDialog(title: string, body: string, ok: string, danger = false): Promise<boolean> {
  return new Promise((resolve) => {
    const d = h('dialog', { 'aria-labelledby': 'dlg-t' });
    d.append(
      frag(`<h2 id="dlg-t" class="h2">${esc(title)}</h2><p class="muted">${esc(body)}</p>
      <div class="row" style="margin-top:18px"><button class="btn ghost small" value="no">Cancel</button>
      <button class="btn small" value="yes" style="${danger ? '--b:#c4372b;color:#fff' : ''}">${esc(ok)}</button></div>`),
    );
    d.querySelectorAll('button').forEach((b) =>
      b.addEventListener('click', () => {
        d.close();
        resolve(b.value === 'yes');
      }),
    );
    d.addEventListener('cancel', () => resolve(false));
    d.addEventListener('close', () => d.remove());
    document.body.append(d);
    d.showModal();
  });
}
