/** Smooth live-waveform renderer (HiDPI canvas). */
export interface WaveData {
  pts: { t: number; v: number }[];
  end: number;
  beats: { t: number }[];
}

export class WaveView {
  private ctx: CanvasRenderingContext2D;
  private scale = 0;
  constructor(
    private canvas: HTMLCanvasElement,
    private windowMs = 6000,
  ) {
    this.ctx = canvas.getContext('2d')!;
  }

  private fit(): { w: number; h: number } {
    const dpr = Math.min(3, window.devicePixelRatio || 1);
    const w = this.canvas.clientWidth || 340;
    const h = this.canvas.clientHeight || 120;
    if (this.canvas.width !== Math.round(w * dpr)) {
      this.canvas.width = Math.round(w * dpr);
      this.canvas.height = Math.round(h * dpr);
    }
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return { w, h };
  }

  draw(d: WaveData | null, active: boolean): void {
    const { w, h } = this.fit();
    const c = this.ctx;
    c.clearRect(0, 0, w, h);
    c.strokeStyle = 'rgba(242,236,226,0.06)';
    c.lineWidth = 1;
    for (let x = w; x > 0; x -= w / 6) {
      c.beginPath();
      c.moveTo(x, 0);
      c.lineTo(x, h);
      c.stroke();
    }
    c.beginPath();
    c.moveTo(0, h / 2);
    c.lineTo(w, h / 2);
    c.stroke();
    if (!d || d.pts.length < 5 || !active) {
      // gentle idle line
      const t = performance.now() / 1000;
      c.strokeStyle = 'rgba(166,156,144,0.35)';
      c.lineWidth = 2;
      c.beginPath();
      for (let x = 0; x <= w; x += 4) c.lineTo(x, h / 2 + Math.sin(x / 22 + t * 2) * 2);
      c.stroke();
      return;
    }
    let maxV = 0.0001;
    for (const p of d.pts) maxV = Math.max(maxV, Math.abs(p.v));
    // smooth autoscale so the trace doesn't jump
    this.scale = this.scale ? this.scale * 0.92 + maxV * 0.08 : maxV;
    const k = (h * 0.4) / Math.max(this.scale, maxV * 0.6);
    const g = c.createLinearGradient(0, 0, w, 0);
    g.addColorStop(0, 'rgba(210,69,47,0)');
    g.addColorStop(0.35, '#d2452f');
    g.addColorStop(1, '#ff9a5c');
    c.strokeStyle = g;
    c.lineWidth = 2.6;
    c.lineJoin = 'round';
    c.lineCap = 'round';
    c.shadowColor = 'rgba(238,122,60,0.55)';
    c.shadowBlur = 10;
    c.beginPath();
    d.pts.forEach((p, i) => {
      const x = w - ((d.end - p.t) / this.windowMs) * w;
      const y = h / 2 - Math.max(-h / 2 + 4, Math.min(h / 2 - 4, p.v * k));
      if (i === 0) c.moveTo(x, y);
      else c.lineTo(x, y);
    });
    c.stroke();
    c.shadowBlur = 0;
    // head dot
    const last = d.pts[d.pts.length - 1];
    c.fillStyle = '#fff1e4';
    c.beginPath();
    c.arc(w - 2, h / 2 - Math.max(-h / 2 + 4, Math.min(h / 2 - 4, last.v * k)), 3.2, 0, Math.PI * 2);
    c.fill();
    // beat ticks
    for (const b of d.beats) {
      const age = d.end - b.t;
      const x = w - (age / this.windowMs) * w;
      c.fillStyle = `rgba(255,154,92,${Math.max(0.15, 1 - age / this.windowMs)})`;
      c.beginPath();
      c.arc(x, 12, 3, 0, Math.PI * 2);
      c.fill();
    }
  }
}

/** Downsample the recent waveform into N normalised points (-1..1) for storage / share card. */
export function snapshot(d: WaveData, n = 140): number[] {
  if (d.pts.length < 10) return [];
  const vals = d.pts.map((p) => p.v);
  const out: number[] = [];
  for (let i = 0; i < n; i++) out.push(vals[Math.floor((i / (n - 1)) * (vals.length - 1))]);
  const m = Math.max(...out.map(Math.abs)) || 1;
  return out.map((v) => Math.round((v / m) * 1000) / 1000);
}
