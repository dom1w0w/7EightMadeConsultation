export type Platform = 'ios' | 'android' | 'desktop';

/** Best-effort platform guess, used only to pick help text. */
export function platform(nav: Pick<Navigator, 'userAgent' | 'maxTouchPoints'> = navigator): Platform {
  const ua = nav.userAgent || '';
  if (/iPhone|iPad|iPod/i.test(ua) || (/Macintosh/i.test(ua) && (nav.maxTouchPoints ?? 0) > 1)) return 'ios';
  if (/Android/i.test(ua)) return 'android';
  return 'desktop';
}

/** Flashlight guidance when the browser can't switch the torch on for us. */
export function torchTip(p: Platform): { title: string; body: string } {
  switch (p) {
    case 'ios':
      return {
        title: 'Turn your flashlight on.',
        body: "iPhone browsers can't switch it on for us. Swipe down for Control Center, tap the flashlight, then cover the camera and flash with your fingertip.",
      };
    case 'android':
      return {
        title: 'Turn your flashlight on.',
        body: "This browser couldn't switch it on. Swipe down for Quick Settings and tap Flashlight (or try Chrome), then cover the camera and flash with your fingertip.",
      };
    default:
      return {
        title: 'Best on a phone.',
        body: 'Pulse needs a rear camera with a flashlight. On a computer, open the link on your phone instead, or sit under a bright lamp and cover the webcam fully with a fingertip.',
      };
  }
}
