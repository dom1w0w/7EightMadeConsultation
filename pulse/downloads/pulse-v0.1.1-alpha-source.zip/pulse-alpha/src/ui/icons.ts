const s = (p: string, extra = '') =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${p}</svg>`;

export const icons = {
  heart: s(
    '<path d="M12 20s-7.5-4.6-9.2-9.3C1.6 7.3 3.7 4 7 4c2 0 3.6 1.1 5 3 1.4-1.9 3-3 5-3 3.3 0 5.4 3.3 4.2 6.7C19.5 15.4 12 20 12 20Z"/>',
  ),
  heartFill: `<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 21s-8-4.9-9.9-10C.8 7.4 3.1 3.6 6.8 3.6c2.1 0 3.8 1.1 5.2 3 1.4-1.9 3.1-3 5.2-3 3.7 0 6 3.8 4.7 7.4C20 16.1 12 21 12 21Z"/></svg>`,
  pulse: s('<path d="M2 12h4l2.5-6 4 13 3-9 1.5 2H22"/>'),
  calm: s('<circle cx="12" cy="12" r="3.2"/><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="10.2" opacity=".5"/>'),
  history: s('<path d="M3 3v18h18"/><path d="m7 14 4-4 3 3 5-6"/>'),
  settings: s(
    '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/>',
  ),
  share: s('<path d="M12 3v13"/><path d="m7 8 5-5 5 5"/><path d="M5 13v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6"/>'),
  download: s('<path d="M12 3v13"/><path d="m7 11 5 5 5-5"/><path d="M5 21h14"/>'),
  finger: s(
    '<path d="M9 11V5.5a1.5 1.5 0 0 1 3 0V11"/><path d="M12 10.5V9a1.5 1.5 0 0 1 3 0v2"/><path d="M15 10.5a1.5 1.5 0 0 1 3 0V15a6 6 0 0 1-6 6h-.6a6 6 0 0 1-4.6-2.2L4.3 15.6a1.5 1.5 0 0 1 2.3-1.9L9 16"/>',
  ),
  flash: s('<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z"/>'),
  still: s('<circle cx="12" cy="12" r="9"/><path d="M8 12h8"/>'),
  lock: s('<rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>'),
  info: s('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>'),
  alert: s('<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/>'),
  camera: s(
    '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3Z"/><circle cx="12" cy="13" r="3.5"/>',
  ),
  flame: s(
    '<path d="M12 22c4 0 7-2.7 7-6.8 0-4.4-3.6-6.6-4.5-11.2-2.5 1.7-3.4 4.4-3 6.6-1.2-.6-2.2-1.8-2.5-3.4C6.6 9.6 5 12.4 5 15.2 5 19.3 8 22 12 22Z"/>',
  ),
  trash: s('<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>'),
  arrow: s('<path d="M5 12h14M13 6l6 6-6 6"/>'),
  refresh: s('<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>'),
  x: s('<path d="M18 6 6 18M6 6l12 12"/>'),
  wind: s('<path d="M3 8h11a3 3 0 1 0-3-3"/><path d="M3 12h16a3 3 0 1 1-3 3"/><path d="M3 16h7"/>'),
  shield: s('<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>'),
  phone: s('<rect x="6" y="2" width="12" height="20" rx="2.5"/><path d="M11 18h2"/>'),
  sparkle: s('<path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/>'),
};

/** Larger illustrations for onboarding / empty states. */
export const art = {
  finger: `<svg viewBox="0 0 200 200" aria-hidden="true"><defs><radialGradient id="aG" cx="50%" cy="45%"><stop offset="0" stop-color="#ff6a45"/><stop offset=".7" stop-color="#b3200f"/><stop offset="1" stop-color="#4a0805"/></radialGradient></defs>
    <rect x="52" y="20" width="96" height="160" rx="18" fill="#211d19" stroke="#3a332c" stroke-width="2"/>
    <circle cx="82" cy="52" r="15" fill="#0e0d0c" stroke="#4a423a" stroke-width="2"/><circle cx="82" cy="52" r="7" fill="#2f6bff" opacity=".7"/>
    <circle cx="112" cy="52" r="6" fill="#f2ece2" opacity=".9"/>
    <path d="M60 150c0-46 6-84 22-98 9-8 25-5 30 6 6 13 4 46 4 92" fill="url(#aG)" opacity=".96"/>
    <ellipse cx="88" cy="58" rx="22" ry="18" fill="#ff8a5c" opacity=".35"><animate attributeName="opacity" values=".15;.5;.15" dur="1.1s" repeatCount="indefinite"/></ellipse></svg>`,
  lock: `<svg viewBox="0 0 200 200" aria-hidden="true"><rect x="58" y="34" width="84" height="136" rx="16" fill="#211d19" stroke="#3a332c" stroke-width="2"/>
    <rect x="80" y="92" width="40" height="34" rx="7" fill="#ee7a3c"/><path d="M88 92v-9a12 12 0 0 1 24 0v9" fill="none" stroke="#ee7a3c" stroke-width="6"/>
    <circle cx="100" cy="108" r="4" fill="#1d0e05"/><path d="M100 110v8" stroke="#1d0e05" stroke-width="3" stroke-linecap="round"/>
    <path d="M30 70q-10 30 0 60M170 70q10 30 0 60" fill="none" stroke="#a69c90" stroke-width="3" stroke-dasharray="2 8" stroke-linecap="round"/>
    <path d="M22 48l20 20M178 48l-20 20" stroke="#ef5a4c" stroke-width="4" stroke-linecap="round"/><path d="M42 48l-20 20M158 48l20 20" stroke="#ef5a4c" stroke-width="4" stroke-linecap="round"/></svg>`,
  wellness: `<svg viewBox="0 0 200 200" aria-hidden="true"><circle cx="100" cy="100" r="62" fill="none" stroke="#3a332c" stroke-width="2"/>
    <path d="M30 104h34l10-26 18 54 14-40 8 12h56" fill="none" stroke="#ee7a3c" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
    <rect x="66" y="150" width="68" height="20" rx="10" fill="#211d19" stroke="#6fd3c1" stroke-width="1.5"/><text x="100" y="164" text-anchor="middle" font-family="Inter,sans-serif" font-size="10" font-weight="700" fill="#6fd3c1" letter-spacing="1.5">WELLNESS</text></svg>`,
  empty: `<svg viewBox="0 0 120 80" aria-hidden="true"><path d="M4 44h22l8-18 12 36 10-26 6 8h54" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
};
