import { frag, $ } from './dom';
import { art } from './icons';

declare const __APP_VERSION__: string;

const SLIDES = [
  {
    art: art.finger,
    t: 'Fingertip on the camera',
    p: 'Cover the rear camera and flash with one fingertip. Light shines through your skin, and every heartbeat changes its color a tiny bit. Pulse reads that.',
  },
  {
    art: art.lock,
    t: 'Stays on your phone',
    p: 'The camera is analyzed live, on your device. Nothing is recorded, uploaded or shared. No account, no tracking.',
  },
  {
    art: art.wellness,
    t: 'Wellness, not medicine',
    p: "Pulse gives a wellness estimate of heart rate and breathing. It's not a medical device and can't diagnose anything.",
  },
];

/** Full-screen 3-card intro. Resolves when the user finishes or skips. */
export function showOnboarding(): Promise<void> {
  return new Promise((resolve) => {
    const el = document.createElement('div');
    el.className = 'onb';
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-modal', 'true');
    el.setAttribute('aria-label', 'Welcome to Pulse');
    el.append(
      frag(`<div class="onb-top"><span class="brand-name">Pulse <span class="badge badge-alpha" style="vertical-align:middle" data-build-label>Demo build · Alpha</span></span><button class="linkbtn" type="button" data-skip>Skip</button></div>
      <div class="onb-track" data-track tabindex="0" aria-label="Introduction, 3 slides. Use arrow keys or the Next button.">${SLIDES.map(
        (s, i) => `<div class="slide" aria-roledescription="slide" aria-label="${i + 1} of 3"><div class="slide-in">
          ${i === 0 ? `<p class="build-note" data-build-note>Demo build · early preview (v${__APP_VERSION__})</p>` : ''}
          <div class="art">${s.art}</div><p class="eyebrow">${i + 1} / 3</p><h2>${s.t}</h2><p>${s.p}</p></div></div>`,
      ).join('')}</div>
      <div class="onb-foot"><div class="dots" aria-hidden="true">${SLIDES.map((_, i) => `<i class="${i ? '' : 'on'}"></i>`).join('')}</div>
      <button class="btn block" type="button" data-next>Next</button></div>`),
    );
    document.body.append(el);
    const track = $('[data-track]', el);
    const next = $('[data-next]', el);
    const dots = [...el.querySelectorAll('.dots i')];
    const slideW = () => (track.firstElementChild as HTMLElement).offsetWidth || track.clientWidth;
    let idx = 0;
    let programmatic = 0;
    const update = () => {
      dots.forEach((d, i) => d.classList.toggle('on', i === idx));
      next.textContent = idx === SLIDES.length - 1 ? 'Get started' : 'Next';
    };
    const goTo = (i: number) => {
      idx = Math.max(0, Math.min(SLIDES.length - 1, i));
      programmatic = Date.now();
      track.scrollTo({ left: idx * slideW(), behavior: 'smooth' });
      update();
    };
    track.addEventListener('scroll', () => {
      if (Date.now() - programmatic < 700) return; // ignore our own smooth scroll
      const i = Math.round(track.scrollLeft / slideW());
      if (i !== idx && i >= 0 && i < SLIDES.length) {
        idx = i;
        update();
      }
    });
    track.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight') goTo(idx + 1);
      else if (e.key === 'ArrowLeft') goTo(idx - 1);
      else return;
      e.preventDefault();
    });
    window.addEventListener('resize', () => track.scrollTo({ left: idx * slideW() }));
    const close = () => {
      el.style.transition = 'opacity .3s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 300);
      resolve();
    };
    next.addEventListener('click', () => {
      if (idx >= SLIDES.length - 1) return close();
      goTo(idx + 1);
    });
    $('[data-skip]', el).addEventListener('click', close);
    next.focus();
  });
}
