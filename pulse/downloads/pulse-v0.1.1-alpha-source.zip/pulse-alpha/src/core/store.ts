/** Local-only storage. Nothing ever leaves the device. */

export type ReadingKind = 'measure' | 'calm-before' | 'calm-after';

export interface StoredReading {
  id: string;
  /** epoch ms */
  at: number;
  bpm: number;
  breathing: number | null;
  quality: number;
  kind: ReadingKind;
  /** produced in Demo mode (simulated signal) */
  demo: boolean;
  /** for calm-after: the paired before-bpm */
  before?: number;
  /** compact waveform snapshot for the share card (normalised -1..1) */
  wave?: number[];
}

export interface Settings {
  demo: boolean;
  haptics: boolean;
  beatHaptics: boolean;
  onboarded: boolean;
}

const KEY_R = 'pulse.readings.v1';
const KEY_S = 'pulse.settings.v1';
export const DEFAULT_SETTINGS: Settings = { demo: false, haptics: true, beatHaptics: false, onboarded: false };

export interface KV {
  getItem(k: string): string | null;
  setItem(k: string, v: string): void;
  removeItem(k: string): void;
}

function safeParse<T>(s: string | null, fb: T): T {
  if (!s) return fb;
  try {
    return JSON.parse(s) as T;
  } catch {
    return fb;
  }
}

export class Store {
  constructor(private kv: KV) {}

  readings(): StoredReading[] {
    const r = safeParse<StoredReading[]>(this.kv.getItem(KEY_R), []);
    return Array.isArray(r) ? r.filter((x) => x && typeof x.bpm === 'number').sort((a, b) => a.at - b.at) : [];
  }

  add(r: Omit<StoredReading, 'id'>): StoredReading {
    const all = this.readings();
    const rec = { ...r, id: `${r.at.toString(36)}-${Math.random().toString(36).slice(2, 7)}` };
    all.push(rec);
    while (all.length > 1000) all.shift();
    this.kv.setItem(KEY_R, JSON.stringify(all));
    return rec;
  }

  remove(id: string): void {
    this.kv.setItem(KEY_R, JSON.stringify(this.readings().filter((r) => r.id !== id)));
  }

  settings(): Settings {
    return { ...DEFAULT_SETTINGS, ...safeParse<Partial<Settings>>(this.kv.getItem(KEY_S), {}) };
  }

  saveSettings(p: Partial<Settings>): Settings {
    const s = { ...this.settings(), ...p };
    this.kv.setItem(KEY_S, JSON.stringify(s));
    return s;
  }

  /** Deletes all readings and resets settings (keeps the intro as seen). */
  clearAll(): void {
    this.kv.removeItem(KEY_R);
    this.kv.setItem(KEY_S, JSON.stringify({ ...DEFAULT_SETTINGS, onboarded: true }));
  }
}

/** Local calendar-day key, e.g. 2026-11-27 */
export function dayKey(ms: number): string {
  const d = new Date(ms);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/**
 * Current daily streak: consecutive days with at least one reading, ending today —
 * or ending yesterday (streak still alive until today ends).
 */
export function streak(readings: { at: number }[], now = Date.now()): { current: number; best: number; today: boolean } {
  const days = new Set(readings.map((r) => dayKey(r.at)));
  const step = (ms: number, n: number) => {
    const d = new Date(ms);
    d.setDate(d.getDate() + n);
    return d.getTime();
  };
  const today = days.has(dayKey(now));
  let cur = 0;
  let c = today ? now : step(now, -1);
  while (days.has(dayKey(c))) {
    cur++;
    c = step(c, -1);
  }
  // best streak
  const sorted = [...days].sort();
  let best = 0;
  let run = 0;
  let prev: string | null = null;
  for (const k of sorted) {
    if (prev) {
      const [y, m, d] = prev.split('-').map(Number);
      run = dayKey(new Date(y, m - 1, d + 1).getTime()) === k ? run + 1 : 1;
    } else run = 1;
    best = Math.max(best, run);
    prev = k;
  }
  return { current: cur, best, today };
}
