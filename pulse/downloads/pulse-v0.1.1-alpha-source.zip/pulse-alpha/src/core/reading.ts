import { median } from '../signal/dsp';
import type { LiveState } from '../signal/processor';

export type ReadingPhase = 'waiting' | 'measuring' | 'paused' | 'done' | 'failed';

export interface ReadingResult {
  bpm: number;
  /** mean signal quality across the accepted part of the read, 0..1 */
  quality: number;
  /** seconds of good signal used */
  seconds: number;
}

export type FailReason = 'timeout' | 'nosignal';

export interface ReadingProgress {
  phase: ReadingPhase;
  /** 0..1 of the required good-signal time */
  progress: number;
  secondsLeft: number;
  result?: ReadingResult;
  reason?: FailReason;
}

/**
 * Turns a stream of live states into a single trustworthy reading.
 * Progress only advances while the signal is good — finger-off, motion and weak
 * signal pause the clock instead of polluting the result. Gives up after a timeout.
 */
export class ReadingSession {
  private good = 0;
  private lastNow = 0;
  private started = 0;
  private samples: { at: number; bpm: number; q: number }[] = [];
  private finished: ReadingProgress | null = null;

  constructor(
    readonly durationSec = 30,
    readonly timeoutSec = 100,
  ) {}

  update(s: LiveState): ReadingProgress {
    if (this.finished) return this.finished;
    const now = s.now;
    if (!this.started) this.started = now;
    const dt = this.lastNow ? Math.min(250, now - this.lastNow) : 0;
    this.lastNow = now;
    const ok = s.status === 'ok' && s.bpm > 0;
    if (ok) {
      this.good += dt;
      this.samples.push({ at: this.good, bpm: s.bpm, q: s.quality });
    }
    const need = this.durationSec * 1000;
    if (this.good >= need) {
      const res = this.compute();
      this.finished = res
        ? { phase: 'done', progress: 1, secondsLeft: 0, result: res }
        : { phase: 'failed', progress: 1, secondsLeft: 0, reason: 'nosignal' };
      return this.finished;
    }
    if (now - this.started > this.timeoutSec * 1000) {
      this.finished = { phase: 'failed', progress: this.good / need, secondsLeft: 0, reason: 'timeout' };
      return this.finished;
    }
    const phase: ReadingPhase = this.good === 0 ? 'waiting' : ok ? 'measuring' : 'paused';
    return { phase, progress: this.good / need, secondsLeft: Math.ceil((need - this.good) / 1000) };
  }

  private compute(): ReadingResult | null {
    // ignore the first third (lock-in transient); keep confident samples
    const cut = this.good / 3;
    const use = this.samples.filter((x) => x.at >= cut && x.q >= 0.4);
    if (use.length < 10) return null;
    const bpm = Math.round(median(use.map((x) => x.bpm)));
    const quality = use.reduce((a, x) => a + x.q, 0) / use.length;
    return { bpm, quality, seconds: Math.round(this.good / 1000) };
  }
}

export function qualityLabel(q: number): 'Strong' | 'Good' | 'Fair' | 'Weak' {
  return q >= 0.75 ? 'Strong' : q >= 0.6 ? 'Good' : q >= 0.45 ? 'Fair' : 'Weak';
}
