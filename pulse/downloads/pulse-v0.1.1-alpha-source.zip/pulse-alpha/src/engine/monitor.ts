import { PulseProcessor, type LiveState } from '../signal/processor';
import { SyntheticPPG, type SynthOptions } from '../signal/synth';
import { CameraSource, type CameraInfo } from './camera';

export interface MonitorOptions {
  video: HTMLVideoElement;
  demo: boolean;
  demoSignal?: SynthOptions;
  onState: (s: LiveState, m: Monitor) => void;
  onBeat?: (t: number) => void;
}

/** Drives a frame source (camera or demo) into the processor on each animation frame. */
export class Monitor {
  readonly processor = new PulseProcessor();
  private cam: CameraSource | null = null;
  private synth: SyntheticPPG | null = null;
  private timer: ReturnType<typeof setInterval> | null = null;
  private raf = 0;
  private running = false;
  private wake: WakeLockSentinel | null = null;
  info: CameraInfo & { demo: boolean } = { torchCapable: false, torchOn: false, demo: false };

  constructor(private o: MonitorOptions) {
    this.processor.onBeat = (t) => o.onBeat?.(t);
  }

  async start(): Promise<void> {
    if (this.o.demo) {
      this.synth = new SyntheticPPG({ seed: Math.floor(Math.random() * 1e6), ...this.o.demoSignal });
      this.info = { torchCapable: false, torchOn: false, demo: true };
      // independent ~30 fps timer so Demo mode works even when rAF is throttled
      this.timer = setInterval(() => {
        const t = performance.now();
        this.processor.ingest(t, this.synth!.sample(t));
      }, 1000 / 30);
    } else {
      this.cam = new CameraSource(this.o.video);
      const info = await this.cam.start();
      this.info = { ...info, demo: false };
    }
    this.running = true;
    this.lockScreen();
    const loop = () => {
      if (!this.running) return;
      const now = performance.now();
      if (this.cam) {
        const f = this.cam.read();
        if (f) this.processor.ingest(now, f);
      }
      this.o.onState(this.processor.state(now), this);
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  async setTorch(on: boolean): Promise<boolean> {
    if (!this.cam) return false;
    const ok = await this.cam.setTorch(on);
    this.info.torchOn = this.cam.info.torchOn;
    return ok;
  }

  private async lockScreen(): Promise<void> {
    try {
      this.wake = (await navigator.wakeLock?.request('screen')) ?? null;
    } catch {
      /* optional */
    }
  }

  stop(): void {
    this.running = false;
    cancelAnimationFrame(this.raf);
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.cam?.stop();
    this.cam = null;
    void this.wake?.release().catch(() => undefined);
    this.wake = null;
  }
}
