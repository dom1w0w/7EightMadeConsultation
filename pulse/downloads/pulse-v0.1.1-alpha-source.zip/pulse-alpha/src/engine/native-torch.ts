import { Capacitor } from '@capacitor/core';

/**
 * Native flashlight for the Capacitor builds (iOS/Android) via @capawesome/capacitor-torch.
 * On the web this is never used — browsers use the MediaStreamTrack `torch` constraint
 * (Android Chrome) or ask the user to switch the flashlight on (iOS Safari).
 */
export const nativeTorch = {
  get native(): boolean {
    return Capacitor.isNativePlatform();
  },
  async available(): Promise<boolean> {
    if (!Capacitor.isNativePlatform()) return false;
    try {
      const { Torch } = await import('@capawesome/capacitor-torch');
      return (await Torch.isAvailable()).available;
    } catch {
      return false;
    }
  },
  async set(on: boolean): Promise<boolean> {
    try {
      const { Torch } = await import('@capawesome/capacitor-torch');
      if (on) await Torch.enable();
      else await Torch.disable();
      return true;
    } catch {
      return false;
    }
  },
};
