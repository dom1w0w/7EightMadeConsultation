import type { FrameStats } from '../signal/finger';
import { nativeTorch } from './native-torch';

export interface CameraInfo {
  torchCapable: boolean;
  torchOn: boolean;
}

export type CameraErrorKind = 'unsupported' | 'insecure' | 'denied' | 'notfound' | 'busy' | 'unknown';

export class CameraError extends Error {
  constructor(
    readonly kind: CameraErrorKind,
    msg: string,
  ) {
    super(msg);
  }
}

function classify(e: unknown): CameraError {
  const name = (e as { name?: string })?.name ?? '';
  if (name === 'NotAllowedError' || name === 'SecurityError') return new CameraError('denied', 'Camera permission was denied.');
  if (name === 'NotFoundError' || name === 'OverconstrainedError') return new CameraError('notfound', 'No usable camera was found.');
  if (name === 'NotSupportedError' || name === 'TypeError') return new CameraError('unsupported', 'This browser cannot use the camera.');
  if (name === 'NotReadableError' || name === 'AbortError') return new CameraError('busy', 'The camera is busy in another app.');
  return new CameraError('unknown', (e as Error)?.message || 'Camera error.');
}

/** Rear camera + torch, sampled into compact frame stats. */
export class CameraSource {
  private stream: MediaStream | null = null;
  private track: MediaStreamTrack | null = null;
  private canvas = document.createElement('canvas');
  private ctx: CanvasRenderingContext2D;
  private lastKey = '';
  private useNativeTorch = false;
  info: CameraInfo = { torchCapable: false, torchOn: false };

  constructor(readonly video: HTMLVideoElement) {
    this.canvas.width = this.canvas.height = 48;
    this.ctx = this.canvas.getContext('2d', { willReadFrequently: true })!;
  }

  async start(): Promise<CameraInfo> {
    if (!window.isSecureContext) throw new CameraError('insecure', 'Camera needs a secure (https) page.');
    if (!navigator.mediaDevices?.getUserMedia) throw new CameraError('unsupported', 'This browser cannot use the camera.');
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 640 },
          height: { ideal: 480 },
          frameRate: { ideal: 30, max: 60 },
        },
      });
    } catch (e) {
      throw classify(e);
    }
    this.track = this.stream.getVideoTracks()[0] ?? null;
    const v = this.video;
    v.setAttribute('playsinline', '');
    v.muted = true;
    v.srcObject = this.stream;
    await v.play().catch(() => undefined);
    let caps: MediaTrackCapabilities & { torch?: boolean } = {};
    try {
      caps = (this.track?.getCapabilities?.() ?? {}) as typeof caps;
    } catch {
      /* not supported */
    }
    this.info.torchCapable = !!caps.torch;
    if (!this.info.torchCapable && (await nativeTorch.available())) {
      // Capacitor app: drive the LED natively (needed on iOS, where WebKit has no torch constraint)
      this.useNativeTorch = true;
      this.info.torchCapable = true;
    }
    await this.setTorch(true);
    return this.info;
  }

  async setTorch(on: boolean): Promise<boolean> {
    if (!this.track || !this.info.torchCapable) return false;
    if (this.useNativeTorch) {
      const ok = await nativeTorch.set(on);
      this.info.torchOn = ok ? on : false;
      return ok;
    }
    try {
      await this.track.applyConstraints({ advanced: [{ torch: on } as MediaTrackConstraintSet] });
      this.info.torchOn = on;
      return true;
    } catch {
      this.info.torchOn = false;
      return false;
    }
  }

  /** Sample the centre crop. Returns null if no new frame is available. */
  read(): FrameStats | null {
    const v = this.video;
    if (v.readyState < 2 || !v.videoWidth) return null;
    const side = Math.min(v.videoWidth, v.videoHeight) * 0.6;
    try {
      this.ctx.drawImage(v, (v.videoWidth - side) / 2, (v.videoHeight - side) / 2, side, side, 0, 0, 48, 48);
      const px = this.ctx.getImageData(0, 0, 48, 48).data;
      let r = 0;
      let g = 0;
      let b = 0;
      let rr = 0;
      let n = 0;
      for (let i = 0; i < px.length; i += 8) {
        r += px[i];
        g += px[i + 1];
        b += px[i + 2];
        rr += px[i] * px[i];
        n++;
      }
      r /= n;
      g /= n;
      b /= n;
      const key = `${r.toFixed(3)}|${g.toFixed(3)}`;
      if (key === this.lastKey) return null; // same video frame as last rAF
      this.lastKey = key;
      return { r, g, b, sp: Math.sqrt(Math.max(0, rr / n - r * r)) };
    } catch {
      return null;
    }
  }

  stop(): void {
    if (this.info.torchOn) void this.setTorch(false);
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    this.track = null;
    this.video.srcObject = null;
    this.info = { torchCapable: false, torchOn: false };
  }
}
