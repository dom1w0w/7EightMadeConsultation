import './styles/app.css';
import { registerSW } from 'virtual:pwa-register';
import markUrl from './assets/mark.svg?url';
import { Store } from './core/store';
import { Haptics } from './ui/haptics';
import { frag, $, toast, confirmDialog } from './ui/dom';
import { icons } from './ui/icons';
import type { Ctx, Screen } from './ui/context';
import { measureScreen } from './ui/screens/measure';
import { calmScreen } from './ui/screens/calm';
import { historyScreen } from './ui/screens/history';
import { shareScreen } from './ui/screens/share';
import { settingsScreen } from './ui/screens/settings';
import { showOnboarding } from './ui/onboarding';

declare const __APP_VERSION__: string;

function memoryKV() {
  const m = new Map<string, string>();
  return {
    getItem: (k: string) => m.get(k) ?? null,
    setItem: (k: string, v: string) => void m.set(k, v),
    removeItem: (k: string) => void m.delete(k),
  };
}
let kv: Storage | ReturnType<typeof memoryKV>;
try {
  localStorage.setItem('pulse.probe', '1');
  localStorage.removeItem('pulse.probe');
  kv = localStorage;
} catch {
  kv = memoryKV(); // private mode / storage blocked: app still works for the session
}
const store = new Store(kv);
const haptics = new Haptics(() => store.settings());

const ROUTES: Record<string, { screen: Screen; tab: string; title: string }> = {
  measure: { screen: measureScreen, tab: 'measure', title: 'Measure' },
  calm: { screen: calmScreen, tab: 'calm', title: 'Calm check' },
  history: { screen: historyScreen, tab: 'history', title: 'History' },
  share: { screen: shareScreen, tab: 'history', title: 'Share' },
  settings: { screen: settingsScreen, tab: 'settings', title: 'Settings' },
};

const app = $('#app');
app.append(
  frag(`<div class="app-bg" aria-hidden="true"></div>
  <header class="topbar">
    <a class="brand" href="#/measure" title="Home"><img src="${markUrl}" alt="" width="30" height="30"/>
      <span><span class="brand-name">Pulse</span><span class="brand-by">by 7EightMade</span></span></a>
    <span class="badge badge-alpha badge-build" data-build-label title="Demo build: early preview, v${__APP_VERSION__}">Demo build · Alpha</span>
    <span class="spacer"></span>
    <span class="offline-pill" data-offline hidden>Offline</span>
    <span class="badge badge-demo" data-demo-badge hidden title="Demo mode: simulated signal">Demo</span>
  </header>
  <main id="view" tabindex="-1"></main>
  <nav class="tabbar" aria-label="Main">
    <a class="tab" href="#/measure" data-tab="measure">${icons.pulse}<span>Measure</span></a>
    <a class="tab" href="#/calm" data-tab="calm">${icons.calm}<span>Calm</span></a>
    <a class="tab" href="#/history" data-tab="history">${icons.history}<span>History</span></a>
    <a class="tab" href="#/settings" data-tab="settings">${icons.settings}<span>Settings</span></a>
  </nav>`),
);
const view = $('#view');
const demoBadge = $('[data-demo-badge]');
let cleanups: (() => void)[] = [];

const ctx: Ctx = {
  store,
  haptics,
  settings: () => store.settings(),
  setSettings: (p) => {
    store.saveSettings(p);
    syncChrome();
  },
  go: (r) => {
    if (location.hash === `#/${r}`) void route();
    else location.hash = `#/${r}`;
  },
  onLeave: (fn) => cleanups.push(fn),
};

function syncChrome() {
  demoBadge.hidden = !store.settings().demo;
}

async function route() {
  const [path, qs] = location.hash.replace(/^#\/?/, '').split('?');
  const r = ROUTES[path] ?? ROUTES.measure;
  cleanups.forEach((f) => f());
  cleanups = [];
  document.querySelectorAll<HTMLElement>('[data-tab]').forEach((t) => {
    if (t.dataset.tab === r.tab) t.setAttribute('aria-current', 'page');
    else t.removeAttribute('aria-current');
  });
  document.title = `${r.title} · Pulse by 7EightMade`;
  syncChrome();
  const host = document.createElement('div');
  view.replaceChildren(host);
  window.scrollTo(0, 0);
  r.screen(host, ctx, new URLSearchParams(qs ?? ''));
  if (!store.settings().onboarded) {
    await showOnboarding();
    store.saveSettings({ onboarded: true });
  }
}
window.addEventListener('hashchange', () => void route());
void route();

// Hidden presenter shortcut: press and hold the logo for 1.2 s to toggle Demo mode (also in Settings).
{
  const brand = $('.brand');
  let timer = 0;
  let fired = false;
  const cancel = () => clearTimeout(timer);
  brand.addEventListener('pointerdown', () => {
    fired = false;
    timer = window.setTimeout(async () => {
      fired = true;
      haptics.phase();
      const on = !store.settings().demo;
      const ok = await confirmDialog(
        on ? 'Turn on Demo mode?' : 'Turn off Demo mode?',
        on ? 'Readings will be simulated (not your pulse) and labelled DEMO.' : 'Pulse will read your real pulse with the camera again.',
        on ? 'Turn on' : 'Turn off',
      );
      if (ok) {
        ctx.setSettings({ demo: on });
        toast(on ? 'Demo mode on: simulated signal' : 'Demo mode off: real camera');
        void route();
      }
    }, 1200);
  });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach((e) => brand.addEventListener(e, cancel));
  brand.addEventListener('contextmenu', (e) => e.preventDefault());
  brand.addEventListener('click', (e) => {
    if (fired) e.preventDefault();
  });
}

// offline indicator
const off = $('[data-offline]');
const net = () => (off.hidden = navigator.onLine);
window.addEventListener('online', net);
window.addEventListener('offline', net);
net();

// PWA: offline cache + update prompt
const updateSW = registerSW({
  immediate: true,
  onNeedRefresh() {
    toast('Update ready: tap to refresh');
    document.querySelector('.toast')?.addEventListener('click', () => void updateSW(true), { once: true });
    (document.querySelector('.toast') as HTMLElement | null)?.style.setProperty('pointer-events', 'auto');
  },
});
