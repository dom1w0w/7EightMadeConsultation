import type { CapacitorConfig } from '@capacitor/cli';

// Native shells for iOS / Android wrap the same web build (dist/).
// See docs/NATIVE.md and docs/BUILD.md.
const config: CapacitorConfig = {
  appId: 'com.seveneightmade.pulse',
  appName: 'Pulse (Demo)',
  webDir: 'dist',
  backgroundColor: '#0e0d0c',
  android: { allowMixedContent: false },
  ios: { contentInset: 'always', backgroundColor: '#0e0d0c' },
};

export default config;
