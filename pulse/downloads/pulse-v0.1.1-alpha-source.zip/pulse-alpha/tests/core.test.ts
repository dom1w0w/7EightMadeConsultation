import { describe, expect, it } from 'vitest';
import { ReadingSession, qualityLabel } from '../src/core/reading';
import { Store, streak, dayKey, type KV } from '../src/core/store';
import type { LiveState } from '../src/signal/processor';

const mem = (): KV => {
  const m = new Map<string, string>();
  return { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => void m.set(k, v), removeItem: (k) => void m.delete(k) };
};
const st = (now: number, p: Partial<LiveState> = {}): LiveState => ({
  now,
  status: 'ok',
  finger: 'ok',
  bpm: 70,
  quality: 0.8,
  channel: 'red',
  ...p,
});

describe('ReadingSession', () => {
  it('completes after 30 s of good signal with the median bpm', () => {
    const s = new ReadingSession(30);
    let p = s.update(st(0));
    for (let t = 0; t <= 31000; t += 33) p = s.update(st(t, { bpm: t < 10000 ? 90 : 71 }));
    expect(p.phase).toBe('done');
    expect(p.result!.bpm).toBe(71);
    expect(p.result!.seconds).toBe(30);
  });

  it('pauses (does not advance) on motion or finger-off', () => {
    const s = new ReadingSession(30);
    for (let t = 0; t <= 10000; t += 50) s.update(st(t));
    let p = s.update(st(10050, { status: 'motion' }));
    for (let t = 10100; t <= 20000; t += 50) p = s.update(st(t, { status: 'nofinger', bpm: 0, quality: 0 }));
    expect(p.phase).toBe('paused');
    expect(p.progress).toBeGreaterThan(0.3);
    expect(p.progress).toBeLessThan(0.36);
  });

  it('fails with timeout when the signal never settles', () => {
    const s = new ReadingSession(30, 20);
    let p = s.update(st(0, { status: 'weak' }));
    for (let t = 0; t <= 21000; t += 50) p = s.update(st(t, { status: 'weak' }));
    expect(p.phase).toBe('failed');
    expect(p.reason).toBe('timeout');
  });

  it('fails with nosignal if quality was too low to trust', () => {
    const s = new ReadingSession(5);
    let p = s.update(st(0));
    for (let t = 0; t <= 6000; t += 33) p = s.update(st(t, { quality: 0.36 }));
    expect(p.phase).toBe('failed');
    expect(p.reason).toBe('nosignal');
  });

  it('labels quality', () => {
    expect(qualityLabel(0.9)).toBe('Strong');
    expect(qualityLabel(0.65)).toBe('Good');
    expect(qualityLabel(0.5)).toBe('Fair');
    expect(qualityLabel(0.2)).toBe('Weak');
  });
});

describe('Store', () => {
  it('adds, lists sorted, removes and survives corrupt data', () => {
    const kv = mem();
    const s = new Store(kv);
    s.add({ at: 2, bpm: 70, breathing: 12, quality: 0.8, kind: 'measure', demo: false });
    const r = s.add({ at: 1, bpm: 65, breathing: null, quality: 0.7, kind: 'measure', demo: false });
    expect(s.readings().map((x) => x.bpm)).toEqual([65, 70]);
    s.remove(r.id);
    expect(s.readings()).toHaveLength(1);
    kv.setItem('pulse.readings.v1', '{not json');
    expect(s.readings()).toEqual([]);
  });

  it('settings default demo OFF (real camera first) and clearAll resets', () => {
    const s = new Store(mem());
    expect(s.settings().demo).toBe(false);
    s.saveSettings({ demo: true, onboarded: true });
    expect(s.settings().demo).toBe(true);
    s.add({ at: 1, bpm: 60, breathing: null, quality: 1, kind: 'measure', demo: true });
    s.clearAll();
    expect(s.readings()).toEqual([]);
    expect(s.settings().demo).toBe(false);
    expect(s.settings().onboarded).toBe(true);
  });
});

describe('streak', () => {
  const day = (d: number, h = 9) => new Date(2026, 10, d, h).getTime();
  const now = day(27, 20);
  it('counts consecutive days ending today', () => {
    expect(streak([{ at: day(25) }, { at: day(26) }, { at: day(27) }, { at: day(27, 10) }], now)).toEqual({
      current: 3,
      best: 3,
      today: true,
    });
  });
  it('stays alive until today ends if yesterday was logged', () => {
    expect(streak([{ at: day(25) }, { at: day(26) }], now).current).toBe(2);
  });
  it('breaks after a missed day and tracks best', () => {
    const r = streak([{ at: day(10) }, { at: day(11) }, { at: day(12) }, { at: day(13) }, { at: day(20) }], now);
    expect(r.current).toBe(0);
    expect(r.best).toBe(4);
  });
  it('handles month boundaries', () => {
    const r = streak(
      [{ at: new Date(2026, 9, 31).getTime() }, { at: new Date(2026, 10, 1).getTime() }],
      new Date(2026, 10, 1, 12).getTime(),
    );
    expect(r.current).toBe(2);
    expect(dayKey(new Date(2026, 0, 5).getTime())).toBe('2026-01-05');
  });
});
