import { describe, expect, it } from 'vitest';
import { acPeriod, BandPass, FS, mean, median, std } from '../src/signal/dsp';
import { fingerState } from '../src/signal/finger';
import { estimateBreathing, type Beat } from '../src/signal/breathing';
import { PulseProcessor } from '../src/signal/processor';
import { SyntheticPPG } from '../src/signal/synth';

/** Feed a synthetic signal at a jittery ~30 fps for `sec` seconds; return processor + last state. */
function run(opts: ConstructorParameters<typeof SyntheticPPG>[0], sec: number, fps = 30, jitter = 6) {
  const p = new PulseProcessor();
  const s = new SyntheticPPG(opts);
  let t = 1000;
  let st = p.state(t);
  let k = 0;
  while (t < 1000 + sec * 1000) {
    t += 1000 / fps + Math.sin(k++ * 1.7) * jitter;
    p.ingest(t, s.sample(t));
    st = p.state(t);
  }
  return { p, st, t };
}

describe('dsp basics', () => {
  it('mean / std / median', () => {
    expect(mean([1, 2, 3, 4])).toBe(2.5);
    expect(std([2, 4, 4, 4, 5, 5, 7, 9])).toBeCloseTo(2.138, 2);
    expect(median([5, 1, 3])).toBe(3);
    expect(median([4, 1, 3, 2])).toBe(2.5);
    expect(median([])).toBe(0);
  });

  it('band-pass keeps 1.2 Hz and rejects DC drift and 8 Hz noise', () => {
    const bp = new BandPass();
    const rms = (f: number, off = 0) => {
      bp.reset();
      const out: number[] = [];
      for (let i = 0; i < FS * 20; i++) out.push(bp.step(off + Math.sin((2 * Math.PI * f * i) / FS)));
      const tail = out.slice(FS * 10);
      return Math.sqrt(mean(tail.map((v) => v * v)));
    };
    expect(rms(1.2)).toBeGreaterThan(0.6);
    expect(rms(0.05)).toBeLessThan(0.05);
    expect(rms(8)).toBeLessThan(0.1);
  });

  it('autocorrelation finds the period and avoids the half-rate harmonic', () => {
    const x = Array.from({ length: 240 }, (_, i) => Math.sin((2 * Math.PI * i) / 25) + 0.3 * Math.sin((4 * Math.PI * i) / 25));
    const r = acPeriod(x, 9, 47)!;
    expect(r.lag).toBeCloseTo(25, 0);
    expect(r.score).toBeGreaterThan(0.8);
  });

  it('autocorrelation returns low score / null for noise', () => {
    let a = 1;
    const rnd = () => (a = (a * 16807) % 2147483647) / 2147483647 - 0.5;
    const x = Array.from({ length: 240 }, rnd);
    const r = acPeriod(x, 9, 47);
    expect(r === null || r.score < 0.3).toBe(true);
  });
});

describe('finger detection', () => {
  it('classifies frames', () => {
    expect(fingerState({ r: 200, g: 40, b: 25, sp: 8 })).toBe('ok');
    expect(fingerState({ r: 70, g: 20, b: 15, sp: 8 })).toBe('dim');
    expect(fingerState({ r: 120, g: 110, b: 100, sp: 40 })).toBe('nofinger');
    expect(fingerState({ r: 10, g: 10, b: 10, sp: 3 })).toBe('dark');
    expect(fingerState({ r: 180, g: 60, b: 40, sp: 45 })).toBe('partial');
    expect(fingerState({ r: 255, g: 230, b: 120, sp: 2 })).toBe('nofinger');
    expect(fingerState(null)).toBe('nofinger');
  });
});

describe('PulseProcessor on synthetic PPG', () => {
  for (const bpm of [52, 68, 84, 110, 140]) {
    it(`locks onto ${bpm} bpm within ±3`, () => {
      const { st } = run({ bpm, resp: 12, seed: bpm }, 20);
      expect(st.status).toBe('ok');
      expect(Math.abs(st.bpm - bpm)).toBeLessThanOrEqual(3);
      expect(st.quality).toBeGreaterThan(0.5);
    });
  }

  it('counts beats close to the true rate', () => {
    const { p } = run({ bpm: 72, resp: 12 }, 30);
    const beats = p.beats.filter((b) => b.t > 6000);
    const span = (beats[beats.length - 1].t - beats[0].t) / 60000;
    expect((beats.length - 1) / span).toBeGreaterThan(68);
    expect((beats.length - 1) / span).toBeLessThan(76);
  });

  it('tracks a falling heart rate (calm check)', () => {
    const { st } = run({ bpm: 84, endBpm: 66, driftSec: 10, resp: 8 }, 30);
    expect(Math.abs(st.bpm - 66)).toBeLessThanOrEqual(3);
  });

  it('is robust at 15 fps (low-end cameras)', () => {
    const { st } = run({ bpm: 78, resp: 14 }, 20, 15, 3);
    expect(st.status).toBe('ok');
    expect(Math.abs(st.bpm - 78)).toBeLessThanOrEqual(4);
  });

  it('reports no finger when the lens is uncovered', () => {
    const p = new PulseProcessor();
    for (let t = 0; t < 5000; t += 33) p.ingest(t, { r: 120, g: 115, b: 110, sp: 50 });
    expect(p.state(5000).status).toBe('nofinger');
  });

  it('flags motion on a sudden brightness jump', () => {
    const p = new PulseProcessor();
    const s = new SyntheticPPG({ bpm: 70 });
    let t = 0;
    for (; t < 12000; t += 33) p.ingest(t, s.sample(t));
    const f = s.sample(t);
    p.ingest(t, { ...f, r: f.r * 0.8 });
    expect(p.state(t + 10).status).toBe('motion');
  });

  for (const [bpm, resp] of [
    [60, 10],
    [75, 7],
    [85, 16],
    [90, 20],
  ]) {
    it(`breathing ${resp}/min at ${bpm} bpm within ±2 over a 30 s read`, () => {
      const { p, t } = run({ bpm, resp, seed: resp }, 40);
      const br = p.breathing(t - 31000);
      expect(br).not.toBeNull();
      expect(Math.abs(br!.rate - resp)).toBeLessThanOrEqual(2);
    });
  }

  it('does not flag motion on a clean, still signal', () => {
    const { p } = run({ bpm: 95, resp: 15 }, 30);
    expect(p.beats.filter((b) => b.t > 8000 && b.motion)).toHaveLength(0);
  });

  it('estimates breathing rate from beat modulation', () => {
    const { p } = run({ bpm: 70, resp: 12, seed: 3 }, 40);
    const br = p.breathing(4000);
    expect(br).not.toBeNull();
    expect(Math.abs(br!.rate - 12)).toBeLessThanOrEqual(3);
  });
});

describe('breathing estimate guards', () => {
  it('returns null for too few beats', () => {
    const beats: Beat[] = Array.from({ length: 8 }, (_, i) => ({ t: i * 800, amp: 1 }));
    expect(estimateBreathing(beats)).toBeNull();
  });
});
