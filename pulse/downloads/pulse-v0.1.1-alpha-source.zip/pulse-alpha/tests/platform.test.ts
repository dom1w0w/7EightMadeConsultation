import { describe, expect, it } from 'vitest';
import { platform, torchTip } from '../src/ui/platform';

describe('platform-aware flashlight tip', () => {
  it('detects platforms', () => {
    expect(platform({ userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X)', maxTouchPoints: 5 })).toBe('ios');
    expect(platform({ userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', maxTouchPoints: 5 })).toBe('ios'); // iPadOS
    expect(platform({ userAgent: 'Mozilla/5.0 (Linux; Android 15; Pixel 9)', maxTouchPoints: 5 })).toBe('android');
    expect(platform({ userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)', maxTouchPoints: 0 })).toBe('desktop');
    expect(platform({ userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', maxTouchPoints: 0 })).toBe('desktop');
  });
  it('gives platform-specific copy', () => {
    expect(torchTip('ios').body).toMatch(/Control Center/);
    expect(torchTip('android').body).toMatch(/Quick Settings/);
    expect(torchTip('desktop').body).not.toMatch(/Control Center|iPhone/);
  });
});
