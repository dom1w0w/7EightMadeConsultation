# Changelog

## 0.1.1-alpha (2026-11-27)

Fixes from independent verification.

- A **"Demo build · Alpha"** label is always visible in the header and onboarding. Slide 1 says "Demo build · early preview". The Android app is named "Pulse (Demo)", and the PWA manifest name says "Demo build".
- Demo mode is now hidden: the links are gone from the Measure and error screens. It's only in Settings, or behind a 1.2 s long-press on the logo with a confirmation. Demo results are labelled "Demo mode · simulated".
- Contrast: `--faint` is now #8a8076. All text passes WCAG AA (axe checks this in the E2E run).
- The onboarding carousel works at any width (index math, keyboard arrows, focusable track with a label).
- The result screen has an `<h1>`, and each live reading has an sr-only heading.
- The flashlight tip now depends on the platform (iPhone, Android, desktop).
- Android: `allowBackup=false` plus data-extraction rules, so readings stay off cloud backup.
- Node 22 LTS in CI and `.nvmrc`. No sourcemaps in release builds.
- SETUP.md uses GitHub Desktop (no 100-file web upload). The source zip no longer includes `.git`.
- PRIVACY.md: contact is via a GitHub issue.
- Polish: a `glob` override clears the dev-only `npm audit` warnings. `gradlew` is executable in CI (chmod). Settings section headings are now `<h2>`. "No camera found" points to Settings › Demo mode. PRIVACY explains the INTERNET permission. SETUP notes the expected first red Pages run. README states the MIT license.

## 0.1.0-alpha (2026-11-27)

First alpha.

- Camera PPG heart rate: 30 Hz resampling, Butterworth band-pass, autocorrelation HR with harmonic guard, auto red/green channel, finger-coverage, dim-light and motion detection.
- 30-second reading that pauses on motion or finger-off, with specific recovery tips and a timeout.
- Breathing-rate estimate from pulse modulation.
- Calm check: reading → 60 s guided breathing → reading → change.
- History with daily streak, 7-day strip, trend chart, delete and CSV export.
- Branded share card (Web Share API or PNG download).
- Onboarding (finger placement, privacy, not a medical device), settings, clear data.
- Installable PWA with offline support and an update prompt.
- Auto flashlight on Android Chrome; guided fallback on iOS Safari; native torch plugin for Capacitor builds.
- Demo mode (off by default) with a realistic simulated signal for presentations.
- Removed SpO₂ and blood-pressure estimates from the original Studio demo.
- Capacitor Android project, GitHub Actions for CI, Pages deploy and tagged releases.
