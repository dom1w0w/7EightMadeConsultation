// Renders docs/social-preview.png (1280×640, GitHub social preview) from screenshots.
// Usage: node scripts/social-preview.mjs [screenshotsDir]
import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';

const dir = process.argv[2] || 'docs/screenshots';
const img = (f) => `data:image/png;base64,${readFileSync(`${dir}/${f}.png`).toString('base64')}`;
const font = (f) => `data:font/woff2;base64,${readFileSync(`src/assets/fonts/${f}`).toString('base64')}`;
const oswald = `data:font/ttf;base64,${readFileSync('src/assets/fonts/oswald.ttf').toString('base64')}`;
const mark = `data:image/svg+xml;base64,${readFileSync('src/assets/mark.svg').toString('base64')}`;
const html = `<!doctype html><html><head><style>
@font-face{font-family:Inter;src:url(${font('inter-normal.woff2')});font-weight:100 900}
@font-face{font-family:Fraunces;font-style:italic;src:url(${font('fraunces-italic.woff2')});font-weight:300 900}
@font-face{font-family:Oswald;src:url(${oswald});font-weight:200 700}
*{box-sizing:border-box}body{margin:0;width:1280px;height:640px;overflow:hidden;background:#0e0d0c;color:#f2ece2;font-family:Inter}
.bg{position:absolute;inset:0;background:radial-gradient(70% 90% at 78% 30%,rgba(238,122,60,.30),transparent 60%),radial-gradient(50% 60% at 0% 100%,rgba(47,107,255,.16),transparent 70%)}
.wave{position:absolute;left:0;right:0;bottom:58px;opacity:.22}
.left{position:absolute;left:72px;top:74px;width:560px}
.brand{display:flex;align-items:center;gap:14px}.brand img{width:52px;height:52px;border-radius:13px}
.brand b{font:600 22px Inter;letter-spacing:.22em;color:#a69c90}
.alpha{font:700 13px Inter;letter-spacing:.16em;padding:6px 9px;border-radius:7px;background:rgba(238,122,60,.16);color:#ff9a5c;border:1px solid rgba(238,122,60,.45);margin-left:6px}
h1{font:600 150px/0.86 Oswald;margin:34px 0 0;letter-spacing:.01em;text-transform:uppercase;background:linear-gradient(180deg,#fff1e4 30%,#ee7a3c);-webkit-background-clip:text;color:transparent}
p{font:500 25px/1.38 Inter;color:#d9d0c4;margin:20px 0 0;max-width:520px}
.motto{font:italic 500 30px Fraunces;color:#f2ece2;margin-top:22px}
.chips{display:flex;gap:10px;margin-top:28px;flex-wrap:wrap}.chips span{font:600 15px Inter;padding:9px 14px;border-radius:99px;border:1px solid rgba(242,236,226,.22);color:#c9bfb2}
.phones{position:absolute;right:40px;top:40px;width:620px;height:600px}
.ph{position:absolute;width:236px;border-radius:34px;padding:9px;background:#1d1a17;border:1.5px solid #3a332c;box-shadow:0 30px 70px rgba(0,0,0,.6)}
.ph img{width:100%;display:block;border-radius:26px}
.p1{left:0;top:96px;transform:rotate(-7deg)}.p2{left:192px;top:20px;z-index:2;width:250px}.p3{left:392px;top:96px;transform:rotate(7deg)}
.foot{position:absolute;left:72px;bottom:30px;font:500 14px Inter;color:#776e64;letter-spacing:.04em}
</style></head><body><div class="bg"></div>
<svg class="wave" viewBox="0 0 1280 120" preserveAspectRatio="none" width="1280" height="120"><path d="M0 70 H220 l20-40 30 80 24-60 14 20 H520 l20-40 30 80 24-60 14 20 H820 l20-40 30 80 24-60 14 20 H1280" fill="none" stroke="#ee7a3c" stroke-width="4"/></svg>
<div class="left"><div class="brand"><img src="${mark}"/><b>7EIGHTMADE</b><span class="alpha">ALPHA</span></div>
<h1>Pulse</h1><p>A 30-second heart-rate check with your phone's camera. Private, on-device, works offline.</p>
<div class="motto">Fall down 7, stand up 8.</div>
<div class="chips"><span>Live pulse wave</span><span>Calm check</span><span>Streaks</span><span>PWA · iOS · Android</span></div></div>
<div class="phones"><div class="ph p1"><img src="${img('09-measuring')}"/></div><div class="ph p2"><img src="${img('10-result')}"/></div><div class="ph p3"><img src="${img('14-calm-result')}"/></div></div>
<div class="foot">Wellness estimate · not a medical device</div></body></html>`;
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: 1280, height: 640 } });
await p.setContent(html);
await p.evaluate(() => document.fonts.ready);
await p.waitForTimeout(300);
await p.screenshot({ path: 'docs/social-preview.png' });
await b.close();
console.log('wrote docs/social-preview.png');
