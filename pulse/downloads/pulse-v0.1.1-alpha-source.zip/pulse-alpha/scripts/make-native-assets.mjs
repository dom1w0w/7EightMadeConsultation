// Renders Android launcher icons + splash screens from public/icons/favicon.svg.
// Run after `npx cap add android`:  node scripts/make-native-assets.mjs
import { chromium } from 'playwright';
import { readFileSync, readdirSync, existsSync } from 'node:fs';

const res = new URL('../android/app/src/main/res/', import.meta.url).pathname;
if (!existsSync(res)) {
  console.error('android/ not found. Run: npx cap add android');
  process.exit(1);
}
const svg = readFileSync(new URL('../public/icons/favicon.svg', import.meta.url), 'utf8');
// artwork without the rounded background, for adaptive-icon foreground
const art = svg.replace(/<rect[^>]*\/>/, '');
const BG = '#151210';
const pngSize = (f) => {
  const b = readFileSync(f);
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
};
const browser = await chromium.launch();
const page = await browser.newPage();
async function render(file, w, h, html, transparent = false) {
  await page.setViewportSize({ width: w, height: h });
  await page.setContent(
    `<html><body style="margin:0;background:${transparent ? 'transparent' : BG}">${html}<style>svg{display:block;width:100%;height:100%}</style></body></html>`,
  );
  await page.screenshot({ path: file, omitBackground: transparent, clip: { x: 0, y: 0, width: w, height: h } });
}
const dens = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };
for (const [d, k] of Object.entries(dens)) {
  const L = Math.round(48 * k);
  const F = Math.round(108 * k);
  await render(`${res}mipmap-${d}/ic_launcher.png`, L, L, `<div style="width:${L}px;height:${L}px">${svg}</div>`, true);
  await render(
    `${res}mipmap-${d}/ic_launcher_round.png`,
    L,
    L,
    `<div style="width:${L}px;height:${L}px;border-radius:50%;overflow:hidden">${svg.replace('rx="112"', 'rx="0"')}</div>`,
    true,
  );
  // adaptive foreground: art inside the 66dp safe zone of a 108dp canvas
  const s = Math.round(F * 0.6);
  await render(
    `${res}mipmap-${d}/ic_launcher_foreground.png`,
    F,
    F,
    `<div style="width:${F}px;height:${F}px;display:grid;place-items:center"><div style="width:${s}px;height:${s}px">${art}</div></div>`,
    true,
  );
}
for (const dir of readdirSync(res).filter((x) => x.startsWith('drawable'))) {
  const f = `${res}${dir}/splash.png`;
  if (!existsSync(f)) continue;
  const { w, h } = pngSize(f);
  const s = Math.round(Math.min(w, h) * 0.28);
  await render(
    f,
    w,
    h,
    `<div style="width:${w}px;height:${h}px;display:grid;place-items:center"><div style="width:${s}px;height:${s}px">${svg}</div></div>`,
  );
}
await browser.close();
console.log('native assets written');
