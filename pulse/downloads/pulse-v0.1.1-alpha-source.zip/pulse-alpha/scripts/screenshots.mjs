// End-to-end smoke test + screenshots of every screen at an iPhone-sized viewport.
// Usage: npm run build && npm run preview -- --port 4173 &  then  npm run shots
// Env: BASE_URL (default http://localhost:4173/), SHOTS_DIR (default docs/screenshots)
import { chromium } from 'playwright';
import { mkdirSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';

const axeSrc = readFileSync(createRequire(import.meta.url).resolve('axe-core/axe.min.js'), 'utf8');

const BASE = process.env.BASE_URL || 'http://localhost:4173/';
const DIR = process.env.SHOTS_DIR || 'docs/screenshots';
mkdirSync(DIR, { recursive: true });
const errors = [];
const log = (...a) => console.log('[shots]', ...a);

const browser = await chromium.launch({
  args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'],
});
const phone = { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, serviceWorkers: 'allow' };

function watch(page, tag) {
  page.on('console', (m) => m.type() === 'error' && errors.push(`${tag}: ${m.text()}`));
  page.on('pageerror', (e) => errors.push(`${tag}: ${e.message}`));
}
const a11y = [];
// WCAG 2 A/AA audit with axe-core on every captured screen
async function audit(page, name) {
  await page.addScriptTag({ content: axeSrc }).catch(() => undefined);
  const res = await page.evaluate(async () =>
    (
      await window.axe.run(document, {
        runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'] },
        resultTypes: ['violations'],
      })
    ).violations.map((v) => `${v.id} (${v.impact}) x${v.nodes.length}: ${v.nodes[0]?.target.join(' ')}`),
  );
  if (res.length) a11y.push(`${name}: ${res.join(' | ')}`);
}
const shot = async (page, name) => {
  await page.waitForTimeout(450);
  await page.screenshot({ path: `${DIR}/${name}.png` });
  await audit(page, name);
  log('saved', name);
};
async function expectBuildLabel(page, where) {
  const ok = await page.evaluate(() =>
    [...document.querySelectorAll('[data-build-label]')].some((e) => e.offsetParent !== null && /Demo build/.test(e.textContent)),
  );
  if (!ok) errors.push(`"Demo build" label not visible on ${where}`);
}
const seed = (s, readings) =>
  `localStorage.setItem('pulse.settings.v1', ${JSON.stringify(JSON.stringify(s))});` +
  (readings ? `localStorage.setItem('pulse.readings.v1', ${JSON.stringify(JSON.stringify(readings))});` : '');

// ---------- 1. First run: onboarding + measure idle (real camera is the default) ----------
{
  const ctx = await browser.newContext(phone);
  const page = await ctx.newPage();
  watch(page, 'onboarding');
  await page.goto(BASE);
  await page.waitForSelector('.onb');
  await expectBuildLabel(page, 'launch/onboarding');
  const note = await page.textContent('[data-build-note]');
  if (!/Demo build/.test(note || '')) errors.push('slide 1 build note missing');
  await shot(page, '01-onboarding-finger');
  await page.click('[data-next]');
  await page.waitForTimeout(600);
  await shot(page, '02-onboarding-privacy');
  await page.click('[data-next]');
  await page.waitForTimeout(600);
  await shot(page, '03-onboarding-wellness');
  await page.click('[data-next]');
  await page.waitForSelector('.onb', { state: 'detached' });
  await expectBuildLabel(page, 'measure header');
  if (await page.$('text=/demo mode/i')) errors.push('demo-mode link visible on Measure home (should be hidden)');
  await shot(page, '04-measure-home');
  // PWA checks
  const manifest = await page.evaluate(async () => {
    const href = document.querySelector('link[rel=manifest]')?.getAttribute('href');
    if (!href) return null;
    return (await fetch(href)).json();
  });
  log('manifest', manifest?.name, manifest?.icons?.length, 'icons');
  if (!manifest || manifest.icons.length < 2) errors.push('manifest missing');
  const sw = await page.evaluate(async () => {
    const reg = await Promise.race([navigator.serviceWorker.ready, new Promise((r) => setTimeout(() => r(null), 8000))]);
    return reg ? reg.active?.state : null;
  });
  log('service worker', sw);
  if (sw !== 'activated') errors.push(`service worker not active: ${sw}`);
  // offline: reload with network off — app shell must come from cache
  await page.waitForTimeout(1500);
  await ctx.setOffline(true);
  await page.reload();
  await page.waitForSelector('.hero', { timeout: 10000 });
  log('offline reload OK');
  await shot(page, '05-offline-reload');
  await ctx.setOffline(false);

  // Real camera path (Chromium's fake camera: no fingertip -> guidance + flashlight notice)
  await page.click('[data-start]');
  await page.waitForSelector('.reader');
  await page.waitForTimeout(3500);
  const status = await page.textContent('[data-status]');
  log('camera status:', status);
  await shot(page, '06-camera-live-no-finger');
  await page.click('[data-cancel]');
  await ctx.close();
}

// ---------- 2. Camera permission denied -> clear recovery screen ----------
{
  // Simulate the user tapping "Don't allow" (headless Chromium can't show the real prompt).
  const b2 = await chromium.launch();
  const ctx = await b2.newContext(phone);
  const page = await ctx.newPage();
  watch(page, 'denied');
  await page.addInitScript(seed({ onboarded: true }));
  await page.addInitScript(() => {
    navigator.mediaDevices.getUserMedia = () => Promise.reject(new DOMException('Permission denied', 'NotAllowedError'));
  });
  await page.goto(BASE + '#/measure');
  await page.click('[data-start]');
  await page.waitForSelector('[data-retry]', { timeout: 15000 });
  if (await page.$('text=/demo mode/i')) errors.push('demo-mode link visible on error screen');
  await shot(page, '07-camera-denied');
  await b2.close();
}

// ---------- 3. Demo mode: full reading -> result -> share ----------
const DAY = 864e5;
const past = Array.from({ length: 6 }, (_, i) => ({
  id: `seed${i}`,
  at: Date.now() - (6 - i) * DAY + i * 3600e3,
  bpm: [74, 71, 77, 69, 72, 68][i],
  breathing: [14, 13, 15, 12, 14, 13][i],
  quality: 0.8,
  kind: i === 3 ? 'calm-after' : 'measure',
  before: i === 3 ? 78 : undefined,
  demo: true,
}));
{
  const ctx = await browser.newContext(phone);
  const page = await ctx.newPage();
  watch(page, 'demo');
  await page.addInitScript(seed({ onboarded: true, demo: true }, past));
  await page.goto(BASE + '#/measure');
  await shot(page, '08-measure-home-demo');
  await page.click('[data-start]');
  await page.waitForFunction(() => document.querySelector('[data-bpm]')?.textContent !== '--', null, { timeout: 30000 });
  await page.waitForTimeout(5000);
  await shot(page, '09-measuring');
  await page.waitForSelector('.result', { timeout: 90000 });
  await page.waitForTimeout(1200);
  await shot(page, '10-result');
  const bpm = Number(await page.textContent('[data-num]'));
  log('result bpm', bpm);
  if (!(bpm > 55 && bpm < 90)) errors.push(`unexpected demo bpm ${bpm}`);
  await page.click('a[href^="#/share"]');
  await page.waitForFunction(() => document.querySelector('[data-img]')?.complete && document.querySelector('[data-img]').naturalWidth > 0);
  await shot(page, '11-share-card');
  // save the full-resolution card itself
  const card = await page.evaluate(() => document.querySelector('[data-img]').src);
  const buf = await page.evaluate(async (u) => Array.from(new Uint8Array(await (await fetch(u)).arrayBuffer())), card);
  const { writeFileSync } = await import('node:fs');
  writeFileSync(`${DIR}/share-card-full.png`, Buffer.from(buf));

  // ---------- 4. Calm check ----------
  await page.goto(BASE + '#/calm');
  await page.waitForSelector('[data-go]');
  await shot(page, '12-calm-intro');
  await page.click('[data-go]');
  await page.waitForSelector('.breath [data-disc]', { timeout: 90000 });
  await page.waitForTimeout(2600);
  await shot(page, '13-calm-breathing');
  await page.waitForSelector('.delta', { timeout: 200000 });
  await page.waitForTimeout(1500);
  await shot(page, '14-calm-result');
  log('calm headline', await page.textContent('.delta'));

  // ---------- 5. History, settings ----------
  await page.click('[data-tab=history]');
  await page.waitForSelector('.streak');
  await shot(page, '15-history');
  await page.screenshot({ path: `${DIR}/15b-history-full.png`, fullPage: true });
  await page.click('[data-tab=settings]');
  await page.waitForSelector('#sw-demo');
  await shot(page, '16-settings');
  // clear data flow
  await page.click('[data-clear]');
  await page.waitForSelector('dialog[open]');
  await shot(page, '17-clear-confirm');
  await page.click('dialog button[value=yes]');
  await page.goto(BASE + '#/history');
  await page.waitForSelector('.empty');
  await shot(page, '18-history-empty');
  await ctx.close();
}

// ---------- 6. Desktop 1280x800: onboarding carousel, screens, flashlight tip ----------
{
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  watch(page, 'desktop');
  await page.goto(BASE);
  await page.waitForSelector('.onb');
  await expectBuildLabel(page, 'desktop launch');
  await shot(page, 'desktop-01-onboarding');
  let taps = 0;
  for (const want of ['Next', 'Get started']) {
    await page.click('[data-next]');
    taps++;
    await page.waitForTimeout(800);
    const state = await page.evaluate(() => {
      const t = document.querySelector('[data-track]');
      const w = t.firstElementChild.getBoundingClientRect();
      return { label: document.querySelector('[data-next]').textContent, left: t.scrollLeft, sw: w.width, tw: t.clientWidth };
    });
    if (Math.abs(state.sw - state.tw) > 1) errors.push(`desktop slide width ${state.sw} != track ${state.tw}`);
    if (taps === 1 && state.label !== 'Next') errors.push(`desktop onboarding label after tap 1: ${state.label}`);
    if (taps === 2 && state.label !== want) errors.push(`desktop onboarding label after tap 2: ${state.label}`);
    await shot(page, `desktop-02-onboarding-slide${taps + 1}`);
  }
  await page.click('[data-next]');
  taps++;
  await page
    .waitForSelector('.onb', { state: 'detached', timeout: 3000 })
    .catch(() => errors.push('desktop onboarding did not close in 3 taps'));
  log('desktop onboarding closed after', taps, 'taps');
  await shot(page, 'desktop-03-measure-home');
  await page.click('[data-start]');
  await page.waitForSelector('[data-torch-tip]', { timeout: 10000 });
  const tip = await page.textContent('[data-torch-tip]');
  if (/Control Center|iPhone/.test(tip)) errors.push('desktop torch tip mentions iPhone: ' + tip);
  await shot(page, 'desktop-04-camera-tip');
  await page.click('[data-cancel]');
  for (const r of ['calm', 'history', 'settings']) {
    await page.click(`[data-tab=${r}]`);
    await page.waitForTimeout(500);
    await shot(page, `desktop-05-${r}`);
  }
  await ctx.close();
}

await browser.close();
if (a11y.length) {
  console.error('A11Y VIOLATIONS:\n' + a11y.join('\n'));
  errors.push(`${a11y.length} screens with axe violations`);
}
if (errors.length) {
  console.error('ERRORS:\n' + errors.join('\n'));
  process.exit(1);
}
log('all screens OK, no console errors');
