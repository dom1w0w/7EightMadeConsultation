# Deploy

## GitHub Pages (default)

- `.github/workflows/deploy.yml` runs on every push to `main`: lint → tests → build → publish.
- One-time: **Settings › Pages › Source = GitHub Actions**.
- The base path is set automatically to `/<repo-name>/`, so the site lives at `https://<user>.github.io/<repo-name>/`.
- **Custom domain or a `<user>.github.io` repo:** change `BASE_PATH` in the workflow to `/`, and add the domain under Settings › Pages.
- **Private repo:** Pages needs a paid GitHub plan. A public repo is free.
- **Unlisted demo:** the Pages URL is public to anyone who has it, but nothing links to it. It's fine for presenting. Don't treat it as access control.

## Other hosts

`npm run build`, then upload `dist/` to Netlify, Cloudflare Pages or Vercel. It must be served over **https**. Set `BASE_PATH` if the app isn't at the domain root.

## Sourcemaps

Release builds ship **without** sourcemaps. For debugging, run `SOURCEMAP=1 npm run build`, which writes hidden `.map` files that the app doesn't reference.

## Updates

The service worker caches the app for offline use. When a new version is deployed, users see an **"Update ready: tap to refresh"** toast the next time they open it.

## Releases

1. Update `version` in `package.json` and add an entry to `CHANGELOG.md`.
2. `git tag v0.2.0 && git push origin v0.2.0`
3. `release.yml` publishes a GitHub Release with the web zip and the Android APK attached. Tags starting `v0.` or containing `alpha`/`beta` are marked pre-release.
