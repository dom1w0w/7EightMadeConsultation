# Development

## Commands

|                                     |                                                                                                                      |
| ----------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| `npm run dev`                       | dev server with hot reload (http://localhost:5173)                                                                   |
| `npm test` / `npm run test:watch`   | Vitest unit tests                                                                                                    |
| `npm run lint` / `npm run format`   | ESLint / Prettier                                                                                                    |
| `npm run check`                     | everything CI runs                                                                                                   |
| `npm run build` / `npm run preview` | production build / serve it                                                                                          |
| `npm run icons`                     | re-render PWA icons from `public/icons/favicon.svg`                                                                  |
| `npm run shots`                     | end-to-end run of every screen + screenshots (needs `npm run preview` running and `npx playwright install chromium`) |

## Testing on a phone

The camera needs **https** (localhost is the only exception). Options:

- Deploy to Pages, which is the simplest.
- `npm run dev -- --host` plus a tunnel such as `cloudflared tunnel --url http://localhost:5173`.
- Or switch on **Demo mode** in Settings to test the UI without a camera.

## Code map

```
src/
  signal/          pure DSP, no DOM, fully unit-tested
    dsp.ts         Butterworth biquads, 0.6–3.5 Hz band-pass, autocorrelation period finder
    processor.ts   streaming PPG pipeline (resample → filter → HR → beats → motion gate)
    finger.ts      fingertip/lens-coverage classifier + user guidance
    breathing.ts   breathing rate from beat-interval & amplitude modulation
    synth.ts       realistic synthetic PPG (Demo mode + tests)
  core/
    reading.ts     turns live states into one trustworthy 30 s reading
    store.ts       localStorage history/settings, streak logic
  engine/
    camera.ts      getUserMedia rear camera, torch, frame sampling
    native-torch.ts Capacitor flashlight plugin (native builds)
    monitor.ts     drives a source (camera/demo) into the processor; wake lock
  ui/              screens, components, share card renderer
  main.ts          shell, router, PWA registration
tests/             Vitest specs
scripts/           icon / native-asset generators, screenshot E2E
```

## Signal pipeline

1. **Sample.** Each video frame takes the centre 60% crop down to 48×48 and averages R, G and B. The spread of red across that crop tells us whether the lens is fully covered.
2. **Resample** to a uniform 30 Hz, because camera timing jitters.
3. **Normalise and filter.** Divide by a slow DC average, invert (more blood means less light), then apply a 4th-order Butterworth band-pass at 0.6–3.5 Hz (36–210 bpm). Red and green are filtered in parallel.
4. **Heart rate.** Autocorrelation over an 8 s window, with a harmonic guard and parabolic interpolation. The channel with the more periodic signal wins. The autocorrelation peak is the 0–1 **quality** score.
5. **Beats.** Local-maximum peak picking with an adaptive threshold, a refractory period and sub-sample (parabolic) peak timing. These drive the beat dots, haptics and the breathing estimate.
6. **Motion gate.** A brightness jump of more than 1.4% per sample, and more than 3× the steepest recent pulse slope, flags motion for 1.2 s.
7. **Reading.** `ReadingSession` advances the 30 s clock only while the status is `ok`. It drops the first third of the read and takes the median of confident estimates. It fails with tips after a timeout.
8. **Breathing.** Beat intervals (respiratory sinus arrhythmia) and beat amplitudes are resampled at 4 Hz, then autocorrelation looks for a 5–30 breaths/min period. If it isn't clear, the app shows "—".

## Conventions

- TypeScript strict, no framework, and no runtime dependencies except Capacitor.
- No network calls, analytics or CDNs. Fonts are bundled.
- Any user-visible health wording must stay "estimate" and "wellness".
