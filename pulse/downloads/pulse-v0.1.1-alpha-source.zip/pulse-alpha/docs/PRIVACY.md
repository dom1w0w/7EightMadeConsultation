# Privacy

**Short version: Pulse collects nothing. Everything stays on your phone.**

- **Camera:** frames are read live in memory to measure color changes in your fingertip, then thrown away. Video and images are never recorded, saved or sent anywhere.
- **Readings:** heart rate, breathing estimate, time and a small waveform snapshot are stored only in your browser's local storage (or the app's own storage in the native app) on your device.
- **No accounts, ads, analytics, trackers or cookies.** The app makes no network requests except to load or update itself from where it's hosted.
- **Sharing:** a share card is only created and shared when you tap Share or Save. It's an image containing the reading you chose.
- **Internet permission (Android app):** the app declares INTERNET only to load and update the web app. Pulse sends no readings, images or personal data anywhere.
- **No cloud backup:** the Android app opts out of Android backup and device transfer (`allowBackup=false`), so readings aren't copied to Google's servers.
- **Delete:** Settings › **Clear all data** removes everything. Uninstalling the app or clearing site data does too.
- **Export:** Settings › **Export my readings** downloads a CSV for you.
- **Not a medical device:** Pulse provides wellness estimates only.

Questions or concerns: **open an issue on this project's GitHub repository.**
