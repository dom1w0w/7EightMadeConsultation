# Native apps (Capacitor)

Pulse is one web codebase. Capacitor wraps the same `dist/` build in native iOS and Android shells.

## Why go native

|            | Web (PWA)                                                                 | Native (Capacitor)                                   |
| ---------- | ------------------------------------------------------------------------- | ---------------------------------------------------- |
| Install    | Link → Add to Home Screen                                                 | App Store / Play Store / APK                         |
| Flashlight | Android Chrome: automatic. **iPhone Safari: never**, the user turns it on | Automatic on both, via `@capawesome/capacitor-torch` |
| Haptics    | Android only (Vibration API)                                              | Android; iOS needs `@capacitor/haptics` (TODO)       |
| Cost       | Free                                                                      | Apple $99/yr; Google $25 one-time                    |
| Review     | None                                                                      | Apple + Google review, health-claim scrutiny         |

## Flashlight details

- **Web:** `MediaStreamTrack.applyConstraints({ advanced: [{ torch: true }] })` works on Android Chrome. WebKit (all iOS browsers) has no torch constraint, so the app shows "turn your flashlight on" steps instead.
- **Native:** `src/engine/native-torch.ts` uses `@capawesome/capacitor-torch` when running inside Capacitor and the web torch isn't available.
- **iOS caveat (untested on device):** the WKWebView camera session and the native torch share the same LED. If the torch switches off when the camera starts, toggle it after `getUserMedia` resolves (already the order the app uses) or move capture to a native camera plugin.

## Android

- The project is committed in `android/`, with camera, flash (optional) and vibrate permissions already in `AndroidManifest.xml`.
- `allowBackup="false"` plus data-extraction rules keep readings off Android cloud backup.
- The app label is **"Pulse (Demo)"** while this is a demo build. Change `app_name` in `res/values/strings.xml` and `appName` in `capacitor.config.ts` for a store release.
- The WebView asks for camera permission at runtime through Capacitor's bridge.
- Build steps are in [BUILD.md](BUILD.md).

## iOS

- It's generated on a Mac with `npx cap add ios`. It isn't committed, because it needs Xcode and CocoaPods or SPM.
- Required: `NSCameraUsageDescription` in Info.plist.
- WKWebView supports `getUserMedia` on iOS 14.3+.

## Store review: keep it a wellness app

- **SpO₂ and blood pressure are removed on purpose.** Camera-based SpO₂ and BP estimates are a common reason for App Store rejection (Guideline 1.4.1, inaccurate health data) and can push an app into FDA "medical device" territory. Don't add them back.
- Keep the honest labels: _"Wellness estimate. Not a medical device."_ They appear on every result, in Settings and on share cards.
- Don't claim to detect or diagnose anything (no AFib, arrhythmia or stress-disorder claims).
- Privacy labels: **Data Not Collected** is accurate today (no analytics, no network calls).
- Store fees: **Apple Developer Program $99/year** and **Google Play one-time $25** registration (verify current pricing at sign-up).
- Google Play also requires a privacy policy URL, so you can host `docs/PRIVACY.md`, plus the Health apps declaration form.
