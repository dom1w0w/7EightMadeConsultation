# Presenting Pulse

**Best: your phone with your own pulse.**

1. Open the live link (see [SETUP.md](SETUP.md)) on your phone, then **Add to Home Screen**.
2. Open Pulse and allow the camera.
3. **iPhone:** swipe down and turn the **flashlight on** first. **Android:** it switches on by itself.
4. Rest your hand on a table. Cover the rear camera and flash with your fingertip and press lightly.
5. Tap **Start reading**. The wave appears in about 8 seconds and the result comes after 30 seconds of clean signal.
6. Then show the **Calm check** (2 minutes), **History** and the **Share card**.

**Mirroring to a screen:** iPhone uses Screen Mirroring (AirPlay). Android uses Cast or a USB-C to HDMI cable.

**Backup with no camera or on a laptop:** Settings › **Demo mode** on, or press and hold the Pulse logo for 1.2 s and confirm. A **DEMO** badge shows in the header, and every demo reading is labelled "Demo mode · simulated". Turn it off afterwards the same way.

The header always says **Demo build · Alpha**. That's the build label, which is separate from Demo mode.

**Android without the link:** install the APK from Releases (or `npm run apk`).

Tips: warm hands read best. If it says "Movement detected", rest your arm on something. "Cover the whole lens" means sliding your finger so the preview glows evenly red.
