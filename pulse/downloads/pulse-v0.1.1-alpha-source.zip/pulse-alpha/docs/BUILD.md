# Build Pulse from source

Short steps. Pick the target you need.

**You need:** Node 22 LTS (or newer) and git. Android also needs JDK 21 and the Android SDK (Android Studio installs both). iOS needs a Mac with Xcode 16+.

```bash
git clone https://github.com/<you>/pulse.git
cd pulse
npm install
```

## 1. Web app (PWA)

1. `npm run build`
2. The app is now in `dist/`.
3. Upload `dist/` to any **https** host (the camera needs https).
4. Hosting in a sub-folder? Build with `BASE_PATH=/folder/ npm run build`, or `BASE_PATH=./ npm run build` for "works in any folder".

Check it locally with `npm run preview`, which opens http://localhost:4173.

## 2. Android APK

1. Install **Android Studio**. It includes the SDK and JDK.
2. `npm run apk`
3. The APK is at `android/app/build/outputs/apk/debug/app-debug.apk`.
4. Copy it to your phone and open it. You'll need to allow _Install unknown apps_.

Or open the project in Android Studio with `npm run cap:android` and press ▶ Run with a phone plugged in.

**Command line without Android Studio:** set `JAVA_HOME` (JDK 21) and `ANDROID_HOME` (SDK with `platforms;android-36` and `build-tools`), then `npm run apk`.

## 3. iOS app (Mac only)

1. `npx cap add ios`. This is a one-time step that creates `ios/`.
2. `node scripts/make-native-assets.mjs` makes the Android icons. For iOS, drag `public/icons/icon-512.png` into _App › Assets › AppIcon_ in Xcode.
3. In `ios/App/App/Info.plist`, add `NSCameraUsageDescription` = _"Pulse uses the camera and flashlight to read your pulse from your fingertip. Video never leaves your phone."_
4. `npm run cap:ios`, which opens Xcode.
5. In Xcode: pick your **Team** (Signing & Capabilities), pick your iPhone, then press ▶.

## Release builds & signing (store-ready)

**Android (Play Store)**

1. Make a keystore once: `keytool -genkey -v -keystore pulse-release.jks -alias pulse -keyalg RSA -keysize 2048 -validity 10000`
2. **Keep it safe and never commit it.** `.gitignore` blocks `*.jks`. If you lose it you can't update the app.
3. For CI, add these repo secrets: `ANDROID_KEYSTORE_BASE64` (`base64 -w0 pulse-release.jks`), `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` and `ANDROID_KEY_PASSWORD`. Then the Release workflow also attaches a signed `-release.apk`.
4. Google Play wants an **AAB**: `cd android && ./gradlew bundleRelease`, then sign it with the same key (or use Play App Signing).
5. Bump `versionCode` and `versionName` in `android/app/build.gradle` for every upload.

**iOS (App Store)**

1. You need an Apple Developer account ($99/year).
2. In Xcode, choose Product › **Archive**, then **Distribute App** › App Store Connect.
3. Test with TestFlight before review.

## Automatic builds (GitHub Actions)

| Workflow      | When            | Output                                    |
| ------------- | --------------- | ----------------------------------------- |
| `ci.yml`      | pull requests   | lint + tests + build                      |
| `deploy.yml`  | push to `main`  | live site on GitHub Pages                 |
| `release.yml` | push a tag `v*` | GitHub Release with web zip + Android APK |

iOS is not built in CI, because it needs macOS runners and Apple signing certificates.
