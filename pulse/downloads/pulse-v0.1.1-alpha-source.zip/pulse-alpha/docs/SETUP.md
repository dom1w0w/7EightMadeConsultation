# Setup: put Pulse on GitHub and get a live link

One step at a time. Each step is one action.

## A. Get the files ready

1. Unzip `pulse-alpha.zip`. You get a folder called `pulse-alpha`.

## B. Put it on GitHub (easiest: GitHub Desktop)

2. Install **GitHub Desktop** from desktop.github.com.
3. Open it and sign in to GitHub.
4. Click **File › Add local repository**.
5. Pick the `pulse-alpha` folder.
6. It says "not a Git repository". Click **create a repository**.
7. Click **Create repository**.
8. Click **Publish repository** (top bar).
9. Name it `pulse`.
10. Tick or untick **Keep this code private**. Pages on a private repo needs a paid plan.
11. Click **Publish repository**.

<details><summary>Prefer the terminal?</summary>

1. Create an empty repo named `pulse` at github.com/new. Don't add any files.
2. `cd pulse-alpha`
3. `git init -b main && git add -A && git commit -m "Pulse v0.1.1-alpha"`
4. `git remote add origin https://github.com/<you>/pulse.git`
5. `git push -u origin main`

</details>

> Don't use GitHub's drag-and-drop web upload. It takes at most 100 files at a time and skips the hidden `.github` folder, which holds the workflows.

## C. Turn on the live link

12. On github.com, open your `pulse` repo.
13. Click **Settings**.
14. Click **Pages** (left menu).
15. Under **Source**, pick **GitHub Actions**.
16. Click the **Actions** tab.

> The first **Deploy to GitHub Pages** run may already show a red ✗ (it started on publish, before Pages was on). That's expected. Just run it again below.

17. Click **Deploy to GitHub Pages**, then **Run workflow**.
18. Wait for the green ✓ (about 1 minute).
19. Click the run, then the link under **deploy**.

Your link is `https://<you>.github.io/pulse/`.

## D. Open it on your phone

20. Open the link on your phone.
21. **iPhone:** tap Share › **Add to Home Screen**.
22. **Android:** tap ⋮ › **Install app**.
23. Open **Pulse** from your home screen.
24. Allow the camera when asked.

## E. (Optional) Make a downloadable release

25. In GitHub Desktop, click **History**.
26. Right-click the latest commit and choose **Create Tag…**
27. Type `v0.1.1-alpha`, then click **Create Tag**.
28. Click **Push origin**.
29. Wait for **Release** in the Actions tab to go green.
30. Open **Releases**. The web zip and the Android APK are attached.
