/// <reference types="vitest/config" />
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';
import pkg from './package.json' with { type: 'json' };

// GitHub Pages serves project sites from /<repo>/ — CI sets BASE_PATH accordingly.
const base = process.env.BASE_PATH || '/';

export default defineConfig({
  base,
  define: {
    __APP_VERSION__: JSON.stringify(pkg.version),
    __BUILD_DATE__: JSON.stringify(new Date().toISOString().slice(0, 10)),
  },
  // No sourcemaps in release builds; set SOURCEMAP=1 for debugging.
  build: { target: 'es2020', sourcemap: process.env.SOURCEMAP === '1' ? 'hidden' : false },
  plugins: [
    VitePWA({
      registerType: 'prompt',
      injectRegister: false,
      includeAssets: ['icons/favicon.svg', 'icons/apple-touch-icon.png'],
      manifest: {
        id: base,
        name: 'Pulse by 7EightMade (Demo build)',
        short_name: 'Pulse',
        description: 'A 30-second heart-rate wellness check with your phone camera. Private and on-device.',
        lang: 'en',
        start_url: base + '#/measure',
        scope: base,
        display: 'standalone',
        orientation: 'portrait',
        background_color: '#0e0d0c',
        theme_color: '#0e0d0c',
        categories: ['health', 'lifestyle', 'fitness'],
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icons/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
        shortcuts: [
          { name: 'Measure', url: base + '#/measure' },
          { name: 'Calm check', url: base + '#/calm' },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,svg,png,woff2,ttf,webmanifest}'],
        navigateFallback: 'index.html',
        cleanupOutdatedCaches: true,
      },
    }),
  ],
  test: { environment: 'node', include: ['tests/**/*.test.ts'] },
});
