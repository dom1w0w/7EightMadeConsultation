<p align="center"><img src="docs/social-preview.png" alt="Pulse by 7EightMade" width="100%"/></p>

# Pulse by 7EightMade <sup>DEMO BUILD · ALPHA</sup>

> **Demo build: early preview (v0.1.1-alpha).** It's not a finished product. The app shows a "Demo build · Alpha" label at all times, and the Android app is named "Pulse (Demo)".

**A 30-second heart-rate check with your phone's camera.** Put a fingertip over the rear camera and Pulse reads the tiny color change in your skin with every heartbeat. It shows a live pulse wave, your heart rate, and an estimate of your breathing rate. A guided **Calm check** shows how one minute of slow breathing changes your heart rate.

Private by design: the camera is analyzed live **on your device**. Nothing is recorded, uploaded or tracked.

> **Wellness estimate. Not a medical device.** Pulse is not for diagnosing, treating or monitoring any condition. It does **not** measure blood oxygen (SpO₂) or blood pressure.
>
> _Fall down 7, stand up 8._

## Screens

|                            Measure                            |                        Live reading                        |                           Result                            |                           Calm check                            |
| :-----------------------------------------------------------: | :--------------------------------------------------------: | :---------------------------------------------------------: | :-------------------------------------------------------------: |
| <img src="docs/screenshots/04-measure-home.png" width="200"/> | <img src="docs/screenshots/09-measuring.png" width="200"/> |   <img src="docs/screenshots/10-result.png" width="200"/>   | <img src="docs/screenshots/13-calm-breathing.png" width="200"/> |
|                        **Calm result**                        |                    **History & streak**                    |                       **Share card**                        |                          **Settings**                           |
| <img src="docs/screenshots/14-calm-result.png" width="200"/>  |  <img src="docs/screenshots/15-history.png" width="200"/>  | <img src="docs/screenshots/11-share-card.png" width="200"/> |    <img src="docs/screenshots/16-settings.png" width="200"/>    |

_The reading screenshots were taken in **Demo mode** (a simulated signal), because a headless test browser has no fingertip. On a phone, Pulse reads your real pulse; Demo mode is off by default._

## Features

- **Measure:** live waveform, heart rate, a 4-bar signal-quality meter and a 30-second reading. The timer only counts while the signal is clean. Moving, lifting your finger or a weak signal pauses it and tells you how to fix it.
- **Flashlight:** turns on automatically where the browser allows it (Android Chrome). On iPhone Safari it shows clear steps to switch it on yourself. The native app turns it on for you.
- **Breathing rate:** estimated from how your pulse rhythm and strength rise and fall with each breath.
- **Calm check:** a reading, then 60 s of guided breathing (4 s in, 6 s out), then a second reading, and the change between them.
- **History:** a daily streak, a 7-day strip, a trend chart and CSV export. Stored only in this browser.
- **Share card:** a branded image of your wave and BPM, shared through the phone's share sheet or saved as a PNG.
- **Installable and offline:** add it to your home screen and it works with no connection.
- **Accessible:** screen-reader labels, live announcements, visible focus, reduced-motion support and haptics where supported.
- **Demo mode:** a hidden presenter fallback that plays a realistic simulated signal. It's off by default. Turn it on only in Settings, or by holding the logo for 1.2 s. While it's on, a DEMO badge shows and every reading is labelled "Demo mode · simulated".

## Download

- **Use it now (any phone):** open the live link (`https://<your-user>.github.io/<repo>/` once Pages is on). Then:
  - **iPhone:** Safari › Share › **Add to Home Screen**.
  - **Android:** Chrome › ⋮ › **Install app**.
- **Releases:** see the repo's **[Releases](../../releases)** page for:
  - `pulse-web-vX.zip`: the web app, to self-host by unzipping onto any https host (relative paths, so any folder works).
  - `pulse-vX-debug.apk`: the Android app, to **sideload**. Download it on the phone, allow _Install unknown apps_ for your browser, then open it. It's a debug-signed testing build, not from the Play Store.
- **Build it yourself:** see [docs/BUILD.md](docs/BUILD.md) (web, Android APK, iOS via Xcode).

## Quick start (developers)

```bash
npm install
npm run dev        # http://localhost:5173 (camera works on localhost)
npm test           # unit tests (signal processing, reading logic, streaks)
npm run build      # production PWA in dist/
npm run preview    # serve dist/ at http://localhost:4173
```

To test with a real camera on your phone you need **https**, so use the deployed Pages link or a tunnel. See [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md).

## Docs

| Doc                                                               | What's in it                                                     |
| ----------------------------------------------------------------- | ---------------------------------------------------------------- |
| [SETUP.md](docs/SETUP.md)                                         | Put this on GitHub and turn on the live link, one step at a time |
| [BUILD.md](docs/BUILD.md)                                         | Build from source: web, Android APK, iOS                         |
| [DEPLOY.md](docs/DEPLOY.md)                                       | GitHub Pages, custom domain, releases                            |
| [NATIVE.md](docs/NATIVE.md)                                       | Capacitor iOS/Android, flashlight, store fees and review notes   |
| [DEVELOPMENT.md](docs/DEVELOPMENT.md)                             | Code map, signal pipeline, testing                               |
| [PRIVACY.md](docs/PRIVACY.md)                                     | What data exists and where it lives                              |
| [PRESENTING.md](docs/PRESENTING.md)                               | How to demo it live on your phone                                |
| [CONTRIBUTING.md](CONTRIBUTING.md) · [CHANGELOG.md](CHANGELOG.md) |                                                                  |

## Tech

Vite + TypeScript (no UI framework), vite-plugin-pwa (Workbox), Vitest, ESLint + Prettier and Capacitor 8 (Android project included; iOS generated on a Mac). GitHub Actions handle CI, Pages deploys and tagged releases.

## License

MIT license (see [LICENSE](LICENSE)). The owner, 7EightMade, may change the license for future releases. Fonts: Inter, Fraunces and Oswald (SIL Open Font License).
