# Contributing

1. Fork, then `npm install`.
2. Make a branch: `git checkout -b my-change`.
3. Run `npm run check` (lint, format, tests, build) before you push.
4. Open a pull request. CI runs the same checks.

Guidelines:

- Signal-processing changes need a unit test in `tests/`. Use `SyntheticPPG` to make signals.
- Keep it private: no network calls, analytics or third-party CDNs.
- Keep health wording honest ("wellness estimate", "not a medical device"). **Do not add SpO₂ or blood-pressure estimates.**
- Accessibility: every control needs a label, motion respects `prefers-reduced-motion`, and text contrast stays at least 4.5:1.
- Prettier formats the code with `npm run format`.
- `package.json` `overrides` pins `workbox-build`'s `glob` to v14 to clear a dev-only `npm audit` advisory (GHSA-3g3m-2fjr-6pw4 / GHSA-g3hv-75wg-m249). If a future `vite-plugin-pwa` release fixes it upstream, remove the override.
